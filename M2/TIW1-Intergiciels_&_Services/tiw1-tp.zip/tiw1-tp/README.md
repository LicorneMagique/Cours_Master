# TIW1 TP

## Notes

### Framework web réutilisable et indépendant  

Grâce à nos annotations, les contrôleurs de l'application paniers possèdent tous une méthode process() générée automatiquement et leurs paramètres de routage (URL, méthode et paramètres de requêtes) sont convertis en un fichier de configuration interprétable par notre framework, sans aucune connaissance de l'application paniers.

Cela assure à notre framework d'être réutilisable et totalement indépendant de l'application qui se sert de lui.

### Collections de requêtes de tests

Collection de requêtes Postman : [cliquez ici](./TIW1_TP3.postman_collection.json)

## Lancement TP3

```shell
mvn clean install
docker-compose up -d
cd web-framework
mvn clean install
cd ../paniers
mvn clean install
cd ../pico-jetty
mvn clean install exec:java
```

## Lancement TP4

Si la commande `gnome-terminal` n'est pas installée il faut entrer les commandes une à une sans le `&& \`.

```shell
mvn clean && \
docker-compose up -d && \
cd web-framework && \
mvn clean install && \
cd ../paniers && \
mvn clean install && \
cd .. && \
cd pico-jetty && \
gnome-terminal -- mvn clean install exec:java && \
cd ../banque && \
gnome-terminal -- mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=alice" && \
cd ../client-shell && \
gnome-terminal -- mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8083" && \
cd ../impr-back && \
gnome-terminal -- mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8084 --spring.profiles.active=receiver" && \
cd ..
```

### Test

```sheel
ajouter 1 2
ajouter 2
valider
virement --source-compte-id alicebank-12345678 --montant 15 --reference toto --dest-compte-id imprbank-23456788
```
