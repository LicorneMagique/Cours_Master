package fr.univlyon1.m2tiw.tiw1.banque;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.compte.Compte;
import fr.univlyon1.m2tiw.tiw1.banque.compte.CompteRepository;
import fr.univlyon1.m2tiw.tiw1.banque.compte.CompteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.lang.NonNullApi;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

@Component
@Slf4j
public class BanqueApplicationListener implements ApplicationListener<ApplicationReadyEvent> {

    @Value("${tiw1.banque.initialdatafile}")
    private String initialDataFile;
    @Autowired
    private CompteRepository compteRepository;

    @Override
    @Transactional
    public void onApplicationEvent(ApplicationReadyEvent event) {
        if (initialDataFile != null && !initialDataFile.isBlank()) {
            var file = new File(initialDataFile);
            if (file.exists()) {
                var mapper = new ObjectMapper();
                try {
                    var data = mapper.readValue(file, InitialData.class);
                    compteRepository.saveAll(Arrays.asList(data.comptes));
                    log.info("Loaded initial data from {}", file.getAbsolutePath());
                } catch (IOException e) {
                    log.error("Failed to load initial data", e);
                }
            } else {
                log.error("Initial data file not found");
            }
        }
    }
}
