package fr.univlyon1.m2tiw.tiw1.banque;

import fr.univlyon1.m2tiw.tiw1.banque.compte.Compte;

public class InitialData {
    public Compte[] comptes;
}
