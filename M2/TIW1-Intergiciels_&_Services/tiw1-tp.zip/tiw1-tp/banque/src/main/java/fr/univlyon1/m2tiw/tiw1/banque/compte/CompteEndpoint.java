package fr.univlyon1.m2tiw.tiw1.banque.compte;

import fr.univ_lyon1.tiw1_is.banque.service.ObjectFactory;
import fr.univ_lyon1.tiw1_is.banque.service.Virement;
import fr.univ_lyon1.tiw1_is.banque.service.VirementResponse;
import fr.univlyon1.m2tiw.tiw1.banque.exception.BanqueInconnueException;
import fr.univlyon1.m2tiw.tiw1.banque.exception.CompteInconnuException;
import fr.univlyon1.m2tiw.tiw1.banque.exception.SoldeInsuffisantException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;


@Endpoint
@Slf4j
public class CompteEndpoint {
    public final static String NAMESPACE_URI = "http:/univ-lyon1.fr/tiw1-is/banque/service";
    private final ObjectFactory banqueObjectFactory = new ObjectFactory();

    @Autowired
    private CompteService compteService;

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "virement")
    @ResponsePayload
    public VirementResponse virement(@RequestPayload Virement transfert) {
        VirementResponse rep = banqueObjectFactory.createVirementResponse();
        try {
            log.info("** Réception M3 **");
            compteService.virement(transfert.getSrcCompteId(),
                    transfert.getDestCompteId(),
                    transfert.getAmount(),
                    transfert.getReference());
            rep.setOk(true);
            log.info("** Envoi M3R **");
        } catch (SoldeInsuffisantException | BanqueInconnueException | CompteInconnuException e) {
            rep.setOk(false);
            String name = e.getClass().getSimpleName();
            rep.setReason(name.substring(0, name.length() - "Exception".length()));
        }
        return rep;
    }
}
