package fr.univlyon1.m2tiw.tiw1.banque.compte;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.exception.BanqueInconnueException;
import fr.univlyon1.m2tiw.tiw1.banque.exception.CompteExterneInconnuException;
import fr.univlyon1.m2tiw.tiw1.banque.exception.CompteInconnuException;
import fr.univlyon1.m2tiw.tiw1.banque.exception.SoldeInsuffisantException;
import fr.univlyon1.m2tiw.tiw1.banque.externe.BanqueExterneService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class CompteService {
    @Autowired
    private CompteRepository compteRepository;
    @Autowired
    private BanqueExterneService banqueExterneService;
    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Value("${tiw1.banque.id}")
    private String localBankId;
    @Value("${impr.back.banque.queue}")
    private String imprBackQueue;
    private ObjectMapper mapper = new ObjectMapper();

    @Transactional
    public void virementInterne(
            Compte source, Compte destination, double montant
    ) throws SoldeInsuffisantException {
        source.debit(montant);
        destination.credit(montant);
    }

    /**
     * Extrait la banque d'un identifiant de compte
     * Les ids de compte sont de la forme {banque}-{numéro-de-compte-interne}.
     *
     * @param compteId l'identifiant de compte
     * @return l'identifiant de la banque
     */
    public String getBankFromCompte(String compteId) {
        return compteId.substring(0, compteId.indexOf('-'));
    }

    @Transactional
    public void virement(
            String sourceCompteId, String destinationCompteId, double montant, String reference
    ) throws SoldeInsuffisantException, BanqueInconnueException, CompteInconnuException {
        try {
            String destinationBank = getBankFromCompte(destinationCompteId);
            if (localBankId.equals(destinationBank)) {
                Compte source = compteRepository.getById(sourceCompteId);
                Compte destination = compteRepository.getById(destinationCompteId);
                virementInterne(source, destination, montant);
            } else {
                compteRepository.getById(sourceCompteId).debit(montant);
                log.info("** Envoi M4 **");
                banqueExterneService.transfert(
                        destinationBank, sourceCompteId, destinationCompteId, montant, reference);
            }
        } catch (EntityNotFoundException e) {
            throw new CompteInconnuException(e);
        }
    }

    private void notificationVirement(Compte compte, double montant, String reference) {
        if (compte.getQueue() != null) {
            log.info("Envoi de notification crédit compte {}", compte.getId());
            var notification = new NotificationTransfert(montant, reference);
            try {
                String data = mapper.writeValueAsString(notification);
                Queue queue = new Queue(imprBackQueue);
                var rabbitAdmin = new RabbitAdmin(rabbitTemplate.getConnectionFactory());
                rabbitAdmin.declareQueue(queue);
                log.info("** Envoi M5 **");
                rabbitTemplate.convertAndSend(queue.getName(), data);
            } catch (JsonProcessingException e) {
                log.error("Failed to send notification", e);
            }
        }
    }

    @Transactional
    public void receptionVirement(
            String destCompteId, Double montant, String reference
    ) {
        log.info("Reception d'un virement de {} € pour le compte {} avec la référence {}",
                montant, destCompteId, reference);
        Compte destCompte = compteRepository.getById(destCompteId);
        destCompte.credit(montant);
        notificationVirement(destCompte, montant, reference);
    }
}
