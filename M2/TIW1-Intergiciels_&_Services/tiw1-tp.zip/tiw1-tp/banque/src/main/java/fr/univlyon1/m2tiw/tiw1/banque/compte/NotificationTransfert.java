package fr.univlyon1.m2tiw.tiw1.banque.compte;

public class NotificationTransfert {
    public double montant;
    public String reference;

    public NotificationTransfert() {
    }

    public NotificationTransfert(double montant, String reference) {
        this.montant = montant;
        this.reference = reference;
    }
}
