package fr.univlyon1.m2tiw.tiw1.banque.externe;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.exception.BanqueInconnueException;
import fr.univlyon1.m2tiw.tiw1.banque.exception.CompteExterneInconnuException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BanqueExterneService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private ObjectMapper mapper = new ObjectMapper();

    public String banqueQueue(String banqueId) throws BanqueInconnueException {
        return banqueId;
    }

    public void transfert(
            String banqueId,
            String srcCompteId,
            String destCompteId,
            double montant,
            String reference
    ) throws CompteExterneInconnuException, BanqueInconnueException {
        Queue queue = new Queue(banqueId);
        try {
            String data = mapper.writeValueAsString(
                    new TransfertInfos(destCompteId, montant, reference)
            );
            rabbitTemplate.convertAndSend(queue.getName(), data);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize transfert", e);
        }
    }
}
