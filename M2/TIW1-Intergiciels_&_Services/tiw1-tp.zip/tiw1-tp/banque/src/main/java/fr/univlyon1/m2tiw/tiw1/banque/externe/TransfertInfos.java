package fr.univlyon1.m2tiw.tiw1.banque.externe;

public class TransfertInfos {

    public String destCompteId;
    public String reference;
    public Double montant;

    public TransfertInfos(String destCompteId, Double montant, String reference) {
        this.destCompteId = destCompteId;
        this.reference = reference;
        this.montant = montant;
    }

    public TransfertInfos() {
    }
}
