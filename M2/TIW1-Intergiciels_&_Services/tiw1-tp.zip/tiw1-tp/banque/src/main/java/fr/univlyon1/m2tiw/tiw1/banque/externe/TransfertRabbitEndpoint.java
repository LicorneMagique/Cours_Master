package fr.univlyon1.m2tiw.tiw1.banque.externe;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.compte.CompteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RabbitListener(queuesToDeclare = {
        @Queue("${tiw1.banque.id}")
})
public class TransfertRabbitEndpoint {

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private CompteService compteService;

    @RabbitHandler
    public void receiveTransfert(String data) {
        try {
            TransfertInfos infos = mapper.readValue(data, TransfertInfos.class);
            log.info("** Réception M4 **");
            compteService.receptionVirement(
                    infos.destCompteId, infos.montant, infos.reference
            );
        } catch (JsonProcessingException e) {
            log.error("Unable to parse message", e);
        }
    }
}
