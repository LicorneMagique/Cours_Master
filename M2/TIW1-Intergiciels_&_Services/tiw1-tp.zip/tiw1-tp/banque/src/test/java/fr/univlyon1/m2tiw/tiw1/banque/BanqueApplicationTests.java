package fr.univlyon1.m2tiw.tiw1.banque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
