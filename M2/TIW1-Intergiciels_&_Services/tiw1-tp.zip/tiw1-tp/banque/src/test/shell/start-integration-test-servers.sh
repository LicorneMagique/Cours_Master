#!/usr/bin/env bash

cd $(dirname $0)

start_server="java -jar ../../../target/banque-2021-SNAPSHOT.jar "
$start_server --tiw1.banque.initialdatafile=../../../alice.json --tiw1.banque.id=alicebank & alicepid=$!
$start_server --tiw1.banque.initialdatafile=../../../impr.json --tiw1.banque.id=imprbank --server.port=8081
kill $!
