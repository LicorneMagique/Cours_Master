package fr.univlyon1.m2.tiw1.cataloguemodeles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogueModelesApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatalogueModelesApplication.class, args);
    }

}
