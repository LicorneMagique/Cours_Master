package fr.univlyon1.m2.tiw1.cataloguemodeles.controllers;

import fr.univlyon1.m2.tiw1.cataloguemodeles.services.ModeleService;
import fr.univlyon1.m2.tiw1.cataloguemodeles.services.NoSuchModeleException;
import fr.univlyon1.m2.tiw1.cataloguemodeles.services.dto.ModeleDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping(path = "/modele")
public class ModeleController {

    private final ModeleService modeleService;

    public ModeleController(ModeleService modeleService) {
        this.modeleService = modeleService;
    }

    @ResponseBody
    @PostMapping
    public ResponseEntity<ModeleDTO> createModele(@RequestBody ModeleDTO modeleDTO) {
        return new ResponseEntity<>(modeleService.createModele(modeleDTO), HttpStatus.CREATED);
    }


    @ResponseBody
    @GetMapping
    public Collection<ModeleDTO> getAll() {
        return modeleService.getAllModeles();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ModeleDTO> getVM(@PathVariable("id") long id) {
        try {
            return new ResponseEntity<>(modeleService.getModele(id), HttpStatus.OK);
        } catch (NoSuchModeleException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
