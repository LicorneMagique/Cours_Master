package fr.univlyon1.m2.tiw1.cataloguemodeles.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Informations sur un modèle 3D.
 */
@Entity
public class Modele {
    @Id
    @GeneratedValue
    private Long id;
    private String nom;

    /**
     * L'identifiant du modèle
     * @return l'id
     */
    public Long getId() {
        return id;
    }

    /**
     * Change l'identifiant du modèle.
     * Cette méthode ne devrait pas être utilisée dans le code métier.
     * @param id le nouvel identifiant
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Le nom du modèle
     * @return le nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Change le nom du modèle
     * @param nom le nouveau nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }
}
