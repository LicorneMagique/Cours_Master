package fr.univlyon1.m2.tiw1.cataloguemodeles.repositories;

import fr.univlyon1.m2.tiw1.cataloguemodeles.models.Modele;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ModeleRepository extends JpaRepository<Modele, Long> {
}
