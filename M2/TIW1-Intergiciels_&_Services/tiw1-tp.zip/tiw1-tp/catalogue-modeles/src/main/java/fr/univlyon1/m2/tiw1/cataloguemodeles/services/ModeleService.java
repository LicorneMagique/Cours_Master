package fr.univlyon1.m2.tiw1.cataloguemodeles.services;

import fr.univlyon1.m2.tiw1.cataloguemodeles.models.Modele;
import fr.univlyon1.m2.tiw1.cataloguemodeles.services.dto.ModeleDTO;
import fr.univlyon1.m2.tiw1.cataloguemodeles.repositories.ModeleRepository;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ModeleService {

    private final ModeleRepository modeleRepository;
    private final Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

    public ModeleService(ModeleRepository modeleRepository) {
        this.modeleRepository = modeleRepository;
        initMockModeles();
    }

    private void initMockModeles() {
        for (Long i = 0L; i < 12; i++) {
            Modele modele = new Modele();
            modele.setId(i);
            modele.setNom("Modèle " + i);
            modeleRepository.save(modele);
        }
    }

    /**
     * Créée un mouveau modèle en base.
     * @param modeleDTO Les données du modèle. Les id sont ignorés.
     * @return le dto du modèle tel qu'enregistré en base
     */
    public ModeleDTO createModele(ModeleDTO modeleDTO) {
        modeleDTO.id = null;
        Modele modele = new Modele();
        modele.setNom(modeleDTO.nom);
        modele = modeleRepository.save(modele);
        return ModeleDTO.fromModele(modele);
    }

    /**
     * La description (en DTO) de tous les modèles enregistrés en base.
     * @return la liste des modèles.
     */
    public Collection<ModeleDTO> getAllModeles() {
        return modeleRepository.findAll().stream()
                .map(ModeleDTO::fromModele)
                .collect(Collectors.toList());
    }

    public ModeleDTO getModele(long id) throws NoSuchModeleException {
        logger.info("** Réception M8 **");
        Optional<Modele> modele = modeleRepository.findById(id);
        if (modele.isPresent()) {
            logger.info("** Envoi M8R **");
            return ModeleDTO.fromModele(modele.get());
        } else {
            throw new NoSuchModeleException("No Modele " + id);
        }
    }
}
