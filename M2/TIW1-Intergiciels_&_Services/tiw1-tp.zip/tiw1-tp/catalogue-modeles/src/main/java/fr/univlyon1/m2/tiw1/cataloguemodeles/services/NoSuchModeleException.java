package fr.univlyon1.m2.tiw1.cataloguemodeles.services;

public class NoSuchModeleException extends Exception {
    public NoSuchModeleException() {
    }

    public NoSuchModeleException(String message) {
        super(message);
    }

    public NoSuchModeleException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoSuchModeleException(Throwable cause) {
        super(cause);
    }

    public NoSuchModeleException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
