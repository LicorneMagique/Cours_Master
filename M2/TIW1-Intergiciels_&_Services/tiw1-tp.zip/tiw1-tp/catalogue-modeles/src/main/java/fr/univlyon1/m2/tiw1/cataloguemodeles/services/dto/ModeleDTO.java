package fr.univlyon1.m2.tiw1.cataloguemodeles.services.dto;

import fr.univlyon1.m2.tiw1.cataloguemodeles.models.Modele;

public class ModeleDTO {
    /**
     * L'identifiant du modèle
     */
    public Long id;
    /**
     * Le nom du modèle
     */
    public String nom;

    /**
     * Construit un DTO à partir d'une entité.
     * @param modele l'entité à représenter.
     * @return le DTO.
     */
    public static ModeleDTO fromModele(Modele modele) {
        ModeleDTO dto = new ModeleDTO();
        dto.id = modele.getId();
        dto.nom = modele.getNom();
        return dto;
    }
}
