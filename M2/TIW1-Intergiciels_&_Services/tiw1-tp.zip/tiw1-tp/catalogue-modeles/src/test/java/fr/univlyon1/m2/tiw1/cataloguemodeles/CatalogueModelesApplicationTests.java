package fr.univlyon1.m2.tiw1.cataloguemodeles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogueModelesApplicationTests {

    @Test
    void contextLoads() {
    }

}
