package fr.univlyon1.m2.tiw1.cataloguemodeles.services;

import fr.univlyon1.m2.tiw1.cataloguemodeles.repositories.ModeleRepository;
import fr.univlyon1.m2.tiw1.cataloguemodeles.services.dto.ModeleDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ModeleServiceTests {
    @Autowired
    private ModeleService modeleService;
    @Autowired
    private ModeleRepository modeleRepository;

    @Test
    public void testCreateModele() {
        var dto = new ModeleDTO();
        dto.nom = "Test - Alice";
        var dto2 = modeleService.createModele(dto);
        assertEquals(dto.nom, dto2.nom);
        assertNotNull(dto2.id);
        assertTrue(modeleRepository.findById(dto2.id).isPresent());
    }

    @Test
    public void testGetAllModele() {
        var curLen = modeleService.getAllModeles().size();
        var dto1 = new ModeleDTO();
        dto1.nom = "Test 2 - Alice";
        var dto2 = new ModeleDTO();
        dto2.nom = "Test 2 - Bob";
        dto1 = modeleService.createModele(dto1);
        dto2 = modeleService.createModele(dto2);
        var all = modeleService.getAllModeles();
        assertTrue(all.stream()
                .map(m -> m.nom)
                .collect(Collectors.toList())
                .containsAll(Arrays.asList(dto1.nom, dto2.nom)));
        assertEquals(curLen + 2, all.size());
    }

    @Test
    public void testGetModeleOK() throws NoSuchModeleException {
        var dto = new ModeleDTO();
        dto.nom = "Test 3 - Alice";
        dto = modeleService.createModele(dto);
        var dto2 = modeleService.getModele(dto.id);
        assertEquals(dto.id, dto2.id);
        assertEquals(dto.nom, dto2.nom);
    }

    @Test
    public void testGetModeleNotFound() {
        var dto = new ModeleDTO();
        dto.nom = "Test 4 - Alice";
        dto = modeleService.createModele(dto);
        try {
            modeleService.getModele(dto.id + 100);
            fail("Modele " + dto.id + 100 + " should not exist");
        } catch (NoSuchModeleException e) {
            // pass
        }
    }
}
