package fr.univlyon1.m2tiw.tiw1.clientshell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientShellApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientShellApplication.class, args);
	}

}
