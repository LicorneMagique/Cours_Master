package fr.univlyon1.m2tiw.tiw1.clientshell.commands;

import fr.univlyon1.m2tiw.tiw1.clientshell.services.BanqueClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.shell.standard.ShellCommandGroup;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;

@ShellComponent
@ShellCommandGroup("banque")
@Slf4j
public class BanqueCommand {

    @Autowired
    @Qualifier(value = "banqueClientSOAP")
    private BanqueClient banqueClient;

    @ShellMethod(key="virement", value = "Effectue un virement")
    public String virement(String sourceCompteId, String destCompteId, double montant, String reference) {
        return banqueClient.virement(sourceCompteId, destCompteId, montant, reference) ?
                "Virement OK" : "Virement échoué";
    }
}
