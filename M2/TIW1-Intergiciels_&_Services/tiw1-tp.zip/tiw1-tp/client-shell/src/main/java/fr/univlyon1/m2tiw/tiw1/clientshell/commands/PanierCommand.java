package fr.univlyon1.m2tiw.tiw1.clientshell.commands;

import fr.univlyon1.m2.tiw1.paniers.services.dto.PanierDTO;
import fr.univlyon1.m2tiw.tiw1.clientshell.services.PanierClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.shell.standard.ShellCommandGroup;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

@ShellComponent()
@ShellCommandGroup("panier")
@Slf4j
public class PanierCommand {

    @Qualifier("panierClientRESTTemplate")
    @Autowired
    private PanierClient panierClient;

    @ShellMethod(key="ajouter", value="Ajouter un modele à imprimer")
    public String ajoutModele3D(
            long modele3DId,
            @ShellOption(defaultValue = "1") int quantite) {
        return panierClient.updateModele3D(modele3DId, quantite).toJSON();
    }

    @ShellMethod(key="supprimer", value="Supprimer un modèle à imprimer")
    public String supprimeModele3D(
            long modele3DId,
            @ShellOption(defaultValue = "1") int quantite) {
        return panierClient.updateModele3D(modele3DId, -quantite).toJSON();
    }

    @ShellMethod(key="valider", value="Valider le panier courant")
    public String validePanier(String email) {
        return panierClient.validerPanier(email).toJSON();
    }

    @ShellMethod(key="get", value="Afficher un panier (par défaut le panier courant)")
    public String getPanier(@ShellOption(defaultValue = ShellOption.NULL) Long id) {
        if (id == null) {
            return panierClient.getPanierCourant().toJSON();
        } else {
            return panierClient.getPanierArchive(id).toJSON();
        }
    }
}
