//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.3.0 
// Voir <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2022.01.02 à 06:56:36 PM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http:/univ-lyon1.fr/tiw1-is/banque/service", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package fr.univlyon1.m2tiw.tiw1.clientshell.gen;
