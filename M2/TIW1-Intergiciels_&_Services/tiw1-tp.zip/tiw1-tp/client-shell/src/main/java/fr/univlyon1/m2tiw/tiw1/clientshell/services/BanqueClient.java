package fr.univlyon1.m2tiw.tiw1.clientshell.services;

public interface BanqueClient {
    boolean virement(String compteSourceId, String compteDestId, double montant, String reference);
}
