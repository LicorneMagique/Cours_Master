package fr.univlyon1.m2tiw.tiw1.clientshell.services;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class BanqueClientConfig {

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("fr.univlyon1.m2tiw.tiw1.clientshell.gen");
        return marshaller;
    }

    @Bean
    public BanqueClient banqueClientSOAP(Jaxb2Marshaller marshaller) {
        BanqueClientSOAP client = new BanqueClientSOAP();
        client.setDefaultUri("http://localhost:8081/ws");
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }
}
