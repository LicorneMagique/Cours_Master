package fr.univlyon1.m2tiw.tiw1.clientshell.services;

import fr.univlyon1.m2tiw.tiw1.clientshell.gen.ObjectFactory;
import fr.univlyon1.m2tiw.tiw1.clientshell.gen.Virement;
import fr.univlyon1.m2tiw.tiw1.clientshell.gen.VirementResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

@Slf4j
public class BanqueClientSOAP extends WebServiceGatewaySupport implements BanqueClient {

    public BanqueClientSOAP() {
    }

    @Override
    public boolean virement(String compteSourceId, String compteDestId, double montant, String reference) {
        log.info("** Envoi M3 **");
        ObjectFactory virementFactory = new ObjectFactory();
        Virement virement = virementFactory.createVirement();
        virement.setSrcCompteId(compteSourceId);
        virement.setDestCompteId(compteDestId);
        virement.setAmount(montant);
        virement.setReference(reference);
        VirementResponse response = (VirementResponse) getWebServiceTemplate().marshalSendAndReceive(virement);
        log.info("** Réception M3R **");
        var reason = response.getReason();
        if (reason != null) {
            logger.error(String.format("Method \"virement\": \"%s\".", reason));
        }
        return response.isOk();
    }
}
