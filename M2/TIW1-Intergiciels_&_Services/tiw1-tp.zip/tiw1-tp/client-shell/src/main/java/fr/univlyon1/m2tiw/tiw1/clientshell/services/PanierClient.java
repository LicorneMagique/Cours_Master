package fr.univlyon1.m2tiw.tiw1.clientshell.services;

import fr.univlyon1.m2.tiw1.paniers.services.dto.PanierDTO;

public interface PanierClient {
    PanierDTO updateModele3D(long modele3DId, int quantite);
    PanierDTO validerPanier(String email);
    PanierDTO getPanierCourant();
    PanierDTO getPanierArchive(long panierId);
}
