package fr.univlyon1.m2tiw.tiw1.clientshell.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2.tiw1.paniers.services.dto.Modele3DDTO;
import fr.univlyon1.m2.tiw1.paniers.services.dto.PanierDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

@Service
@Slf4j
public class PanierClientRESTTemplate implements PanierClient {

    private final RestTemplate restTemplate;
    private final HttpHeaders headers;
    private final ObjectMapper objectMapper;
    private final String baseUrl = "http://localhost:8080";

    PanierClientRESTTemplate() {
        this.restTemplate = new RestTemplate();
        this.headers = new HttpHeaders();
        this.headers.setContentType(MediaType.APPLICATION_JSON);
        this.objectMapper = new ObjectMapper();
    }

    private <T> T getObjectFromResponse(ResponseEntity<String> response, Class<T> t) {
        T object = null;
        try {
            object = objectMapper.readValue(response.getBody(), t);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return object;
    }

    @Override
    public PanierDTO updateModele3D(long modele3DId, int quantite) {
        String url = baseUrl + "/panierCourant/modeles";
        Modele3DDTO modele3DDTO = new Modele3DDTO();
        modele3DDTO.setId(modele3DId);

        Map<String, Object> params = Map.of(
                "modele3DDTO", modele3DDTO,
                "quantite", quantite
        );
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(params, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, entity, String.class);
        PanierDTO panierDTO = getObjectFromResponse(response, PanierDTO.class);
        return panierDTO;
    }

    @Override
    public PanierDTO getPanierCourant() {
        String url = baseUrl + "/panierCourant";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
        PanierDTO panierDTO = getObjectFromResponse(response, PanierDTO.class);
        return panierDTO;
    }

    @Override
    public PanierDTO validerPanier(String email) {
        log.info("** Envoi M1 **");
        String url = baseUrl + "/panierCourant";
        Map<String, String> params = Map.of("email", email);
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(params, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        PanierDTO panierDTO = getObjectFromResponse(response, PanierDTO.class);
        log.info("** Réception M1R **");
        return panierDTO;
    }

    @Override
    public PanierDTO getPanierArchive(long panierId) {
        String url = UriComponentsBuilder.fromHttpUrl(baseUrl + "/panierArchive")
                .queryParam("id", panierId)
                .toUriString();
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
        PanierDTO panierDTO = getObjectFromResponse(response, PanierDTO.class);
        return panierDTO;
    }
}
