package fr.univlyon1.m2tiw.tiw1.clientshell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientShellApplicationTests {

	@Test
	void contextLoads() {
	}

}
