package fr.univlyon1.m2tiw.tiw1.clientshell.services;

import fr.univlyon1.m2.tiw1.paniers.services.dto.PanierDTO;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PanierClientRESTTemplateTests {

    private static PanierClientRESTTemplate panierClientRESTTemplate;
    private static Long numP;

    @BeforeAll
    public static void setup() {
        panierClientRESTTemplate = new PanierClientRESTTemplate();
    }

    @Test
    @Order(1)
    public void updateModele3DTest() {
        PanierDTO panierDTO = panierClientRESTTemplate.updateModele3D(1, 2);
        assert panierDTO.getNumP() == null && panierDTO.getMontant().equals(10.0);
    }

    @Test
    @Order(2)
    public void getPanierCourantTest() {
        PanierDTO panierDTO = panierClientRESTTemplate.getPanierCourant();
        assert panierDTO.getNumP() == null && !panierDTO.isFerme() && panierDTO.getMontant().equals(10.0);
    }

    @Test
    @Order(3)
    public void validerPanierTest() {
        PanierDTO panierDTO = panierClientRESTTemplate.validerPanier("");
        numP = panierDTO.getNumP();
        assert numP != null && panierDTO.isFerme();
    }

    @Test
    @Order(4)
    public void getPanierArchiveTest() {
        PanierDTO panierDTO = panierClientRESTTemplate.getPanierArchive(numP);
        assert panierDTO != null && panierDTO.getMontant().equals(10.0);
    }

}
