package fr.univlyon1.m2tiw.tiw1.imprback;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.compte.NotificationTransfert;
import fr.univlyon1.m2tiw.tiw1.imprback.exceptions.PanierInconnuException;
import fr.univlyon1.m2tiw.tiw1.imprback.services.ImpressionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
public class ImprBackReceiver {

    private ObjectMapper mapper = new ObjectMapper();
    @Autowired
    private ImpressionService impressionService;
    private Integer panierToPay = -1;

    @RabbitListener(queuesToDeclare = @Queue("${impr.back.panier.queue}"))
    @RabbitHandler
    public void receivePanierToPay(String in) {
        log.info("** Réception M2 **");
        Integer numPanier = Integer.valueOf(in);
        panierToPay = numPanier;
    }

    @RabbitListener(queuesToDeclare = @Queue("${impr.back.banque.queue}"))
    @RabbitHandler
    public void receivePayment(String in) throws JsonProcessingException, PanierInconnuException {
        log.info("** Réception M5 **");
        NotificationTransfert infos = mapper.readValue(in, NotificationTransfert.class);
        Integer numP = panierToPay;
        impressionService.createImpression(infos, numP);
    }

    @RabbitListener(queuesToDeclare = @Queue("${tiw1.imprservice.finImpression.queue}"))
    @RabbitHandler
    public void receiveConfirmationImpression(String in) throws PanierInconnuException, JsonProcessingException {
        log.info("** Réception M9 **");
        impressionService.traitementConfirmationImpression(in);
    }
}
