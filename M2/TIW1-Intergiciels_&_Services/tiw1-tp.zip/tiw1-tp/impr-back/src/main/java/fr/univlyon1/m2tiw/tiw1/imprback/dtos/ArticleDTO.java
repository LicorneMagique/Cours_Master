package fr.univlyon1.m2tiw.tiw1.imprback.dtos;

public class ArticleDTO {

    public long id;
    public long modele3DId;
    public int quantite;

    public ArticleDTO(long modele3DId, int quantite) {
        this.modele3DId = modele3DId;
        this.quantite = quantite;
    }

    public ArticleDTO() {
    }
}
