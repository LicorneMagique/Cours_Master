package fr.univlyon1.m2tiw.tiw1.imprback.dtos;

public class PanierDTO {

    public long numP;
    public boolean ferme;
    public double montant;
    public ArticleDTO[] articles;
    public String idCompteBanque;
    public String email;

    public PanierDTO(long numP, double montant, ArticleDTO[] articles, String email) {
        this.numP = numP;
        this.montant = montant;
        this.articles = articles;
        this.email = email;
    }

    // Ne surtout pas supprimer
    public PanierDTO() {
    }
}
