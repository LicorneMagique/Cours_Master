package fr.univlyon1.m2tiw.tiw1.imprback.exceptions;

public class PanierInconnuException extends Exception {
    public long panierId;

    public PanierInconnuException(long panierId) {
        this.panierId = panierId;
    }

    public PanierInconnuException(String message, long panierId) {
        super(message);
        this.panierId = panierId;
    }

    public PanierInconnuException(String message, Throwable cause, long panierId) {
        super(message, cause);
        this.panierId = panierId;
    }

    public PanierInconnuException(Throwable cause, long panierId) {
        super(cause);
        this.panierId = panierId;
    }

    public PanierInconnuException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, long panierId) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.panierId = panierId;
    }
}
