package fr.univlyon1.m2tiw.tiw1.imprback.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.Collection;
import java.util.Objects;

@Entity
public class Impression {
    @Id
    private long numPanier;
    @OneToMany(mappedBy = "impression")
    private Collection<JobImpression> jobs;

    public Impression() {
    }

    public Impression(long numPanier, Collection<JobImpression> jobs) {
        this.numPanier = numPanier;
        this.jobs = jobs;
    }

    public boolean terminee() {
        return jobs.stream().allMatch(j -> j.isTermine());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Impression that = (Impression) o;
        return numPanier == that.numPanier;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numPanier);
    }

    public long getNumPanier() {
        return numPanier;
    }

    public void setNumPanier(long numPanier) {
        this.numPanier = numPanier;
    }

    public Collection<JobImpression> getJobs() {
        return jobs;
    }

    public void setJobs(Collection<JobImpression> jobs) {
        this.jobs = jobs;
    }
}
