package fr.univlyon1.m2tiw.tiw1.imprback.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.util.Objects;
import java.util.UUID;

@Entity
public class JobImpression {
    @Id @GeneratedValue
    private UUID id;
    private boolean termine=false;
    private long modele3d;
    @ManyToOne
    private Impression impression;

    public JobImpression() {
    }

    public JobImpression(long modele3d, Impression impression) {
        this.modele3d = modele3d;
        this.impression = impression;
    }

    public JobImpression(UUID id, boolean termine, long modele3d, Impression impression) {
        this.id = id;
        this.termine = termine;
        this.modele3d = modele3d;
        this.impression = impression;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        JobImpression that = (JobImpression) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public boolean isTermine() {
        return termine;
    }

    public void setTermine(boolean termine) {
        this.termine = termine;
    }

    public long getModele3d() {
        return modele3d;
    }

    public void setModele3d(long modele3d) {
        this.modele3d = modele3d;
    }

    public Impression getImpression() {
        return impression;
    }

    public void setImpression(Impression impression) {
        this.impression = impression;
    }
}
