package fr.univlyon1.m2tiw.tiw1.imprback.services;

import fr.univlyon1.m2tiw.tiw1.imprback.models.Impression;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ImpressionRepository extends JpaRepository<Impression, Long> {
}
