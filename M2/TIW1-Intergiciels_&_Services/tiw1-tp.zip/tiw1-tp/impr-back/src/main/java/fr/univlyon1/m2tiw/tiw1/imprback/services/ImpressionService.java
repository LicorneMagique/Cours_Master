package fr.univlyon1.m2tiw.tiw1.imprback.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.compte.NotificationTransfert;
import fr.univlyon1.m2tiw.tiw1.imprback.dtos.PanierDTO;
import fr.univlyon1.m2tiw.tiw1.imprback.exceptions.PanierInconnuException;
import fr.univlyon1.m2tiw.tiw1.imprback.models.Impression;
import fr.univlyon1.m2tiw.tiw1.imprback.models.JobImpression;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class ImpressionService {

    @Qualifier("panierServiceREST")
    @Autowired
    private PanierService panierService;
    @Autowired
    private ImpressionRepository impressionRepository;
    @Autowired
    private JobImpressionRepository jobImpressionRepository;
    @Autowired
    private JobImpressionService jobImpressionService;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    private ObjectMapper mapper = new ObjectMapper();

    @Transactional
    public void createImpression(NotificationTransfert infos, Integer numP) throws PanierInconnuException, JsonProcessingException {
        if (numP == -1) {
            return;
        }
        log.info("** Envoi M6 **");
        PanierDTO panier = panierService.getPanier(numP);
        if (panier.montant != infos.montant) {
            throw new PanierInconnuException(numP);
        }
        log.info("** Réception M6R **");
        Impression impression = new Impression(numP, new ArrayList<>());
        impression = impressionRepository.save(impression);
        for (var art: panier.articles) {
            for(int i =0; i < art.quantite; i++) {
                JobImpression jobImpression = new JobImpression(art.modele3DId, impression);
                impression.getJobs().add(jobImpression);
                jobImpressionRepository.save(jobImpression);
            }
        }
        for (var job: impression.getJobs()) {
            jobImpressionService.startImpression(job);
        }
    }

    @Transactional
    public void traitementConfirmationImpression(String jobId) throws PanierInconnuException, JsonProcessingException {
        UUID id = UUID.fromString(jobId);
        Optional<JobImpression> job = jobImpressionRepository.findById(id);
        if (job.isEmpty()) {
            return;
        }
        job.get().setTermine(true);
        jobImpressionRepository.save(job.get());
        Impression impression = job.get().getImpression();
        if (impression.terminee()) {
            Long numP = impression.getNumPanier();
            PanierDTO panier = panierService.getPanier(numP);
            String data = mapper.writeValueAsString(panier);
            Queue queue = new Queue(panier.email);
            log.info("** Envoi M10 **");
            rabbitTemplate.convertAndSend(queue.getName(), data);
        }
    }
}
