package fr.univlyon1.m2tiw.tiw1.imprback.services;

import fr.univlyon1.m2tiw.tiw1.imprback.models.JobImpression;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface JobImpressionRepository extends JpaRepository<JobImpression, UUID> {
}
