package fr.univlyon1.m2tiw.tiw1.imprback.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.banque.externe.TransfertInfos;
import fr.univlyon1.m2tiw.tiw1.imprback.models.JobImpression;
import fr.univlyon1.m2tiw.tiw1.imprservice.dto.DemandeDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class JobImpressionService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private ObjectMapper mapper = new ObjectMapper();

    @Value("${tiw1.imprservice.queue}")
    private String queue;

    public void startImpression(JobImpression job) throws JsonProcessingException {
        Queue queue = new Queue(this.queue);
        String data = mapper.writeValueAsString(new DemandeDTO(job.getId(), job.getModele3d(), this.queue));
        log.info("** Envoi M7 **");
        rabbitTemplate.convertAndSend(queue.getName(), data);
    }
}
