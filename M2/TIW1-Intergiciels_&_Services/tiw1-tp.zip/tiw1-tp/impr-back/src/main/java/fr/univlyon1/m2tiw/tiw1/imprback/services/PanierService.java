package fr.univlyon1.m2tiw.tiw1.imprback.services;

import fr.univlyon1.m2tiw.tiw1.imprback.dtos.PanierDTO;
import fr.univlyon1.m2tiw.tiw1.imprback.exceptions.PanierInconnuException;

public interface PanierService {
    PanierDTO getPanier(long panierId) throws PanierInconnuException;
}
