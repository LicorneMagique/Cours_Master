package fr.univlyon1.m2tiw.tiw1.imprback.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.imprback.dtos.PanierDTO;
import fr.univlyon1.m2tiw.tiw1.imprback.exceptions.PanierInconnuException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class PanierServiceREST implements PanierService {

    private final RestTemplate restTemplate;
    private final HttpHeaders headers;
    private final ObjectMapper objectMapper;
    private final String baseUrl = "http://localhost:8080";

    public PanierServiceREST() {
        this.restTemplate = new RestTemplate();
        this.headers = new HttpHeaders();
        this.headers.setContentType(MediaType.APPLICATION_JSON);
        this.objectMapper = new ObjectMapper();
    }

    private <T> T getObjectFromResponse(ResponseEntity<String> response, Class<T> t) {
        T object = null;
        try {
            object = objectMapper.readValue(response.getBody(), t);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return object;
    }

    @Override
    public PanierDTO getPanier(long panierId) throws PanierInconnuException {
        String url = UriComponentsBuilder.fromHttpUrl(baseUrl + "/panierArchive")
                .queryParam("id", panierId)
                .toUriString();
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
        PanierDTO panierDTO = getObjectFromResponse(response, PanierDTO.class);
        if (panierDTO == null) {
            throw new PanierInconnuException(panierId);
        }
        return panierDTO;
    }
}
