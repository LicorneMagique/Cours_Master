package fr.univlyon1.m2tiw.tiw1.imprback;

import fr.univlyon1.m2tiw.tiw1.imprback.models.JobImpression;
import fr.univlyon1.m2tiw.tiw1.imprback.services.JobImpressionRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class ImprBackApplicationTests {

	@Autowired
	private JobImpressionRepository jobImpressionRepository;

	@Test
	void contextLoads() {
	}

	@Test
	void createJob() {
		JobImpression job = new JobImpression();
		job = jobImpressionRepository.save(job);
		assertNotNull(job.getId());
	}

}
