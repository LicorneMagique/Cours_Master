package fr.univlyon1.m2tiw.tiw1.imprservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImprServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImprServiceApplication.class, args);
	}

}
