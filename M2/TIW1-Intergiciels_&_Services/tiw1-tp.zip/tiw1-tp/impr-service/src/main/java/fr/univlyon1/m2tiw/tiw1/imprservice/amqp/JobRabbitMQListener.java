package fr.univlyon1.m2tiw.tiw1.imprservice.amqp;

import fr.univlyon1.m2tiw.tiw1.imprservice.dto.DemandeDTO;
import fr.univlyon1.m2tiw.tiw1.imprservice.services.JobService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

@Component
@Slf4j
public class JobRabbitMQListener implements ApplicationListener<ApplicationReadyEvent> {

    @Autowired
    private JobService jobService;

    @Autowired
    AmqpAdmin amqpAdmin;

    @Value("${tiw1.imprservice.queue}")
    private String jobQueueName;

    @Autowired
    private Flux<DemandeDTO> jobFlux;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        // Comme on est en Spring WebFlux, on programme en asynchrone
        // Cela signifie qu'on ne peut pas utiliser @RabbitListener, mais qu'il faut créer
        // à la main le listener qui reçoit les demandes d'impression et qu'il faut le démarrer
        // en souscrivant au flux
        amqpAdmin.declareQueue(new Queue(jobQueueName));
        // Transforme le flux de demandes en flux d'UUID en traitant les demandes au passage
        jobService.handleJobFlux(jobFlux)
                // log des uuids des traitements effectués
                .subscribe(uuid -> log.info("Job {} traite", uuid));
    }
}
