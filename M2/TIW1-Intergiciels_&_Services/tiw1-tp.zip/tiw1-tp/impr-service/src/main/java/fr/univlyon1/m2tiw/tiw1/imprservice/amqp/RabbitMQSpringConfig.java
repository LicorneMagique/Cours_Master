package fr.univlyon1.m2tiw.tiw1.imprservice.amqp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import fr.univlyon1.m2tiw.tiw1.imprservice.dto.DemandeDTO;
import fr.univlyon1.m2tiw.tiw1.imprservice.services.JobService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.rabbitmq.RabbitFlux;
import reactor.rabbitmq.Receiver;
import reactor.rabbitmq.ReceiverOptions;

// see https://github.com/reactor/reactor-rabbitmq/blob/main/reactor-rabbitmq-samples/src/main/java/reactor/rabbitmq/samples/SpringBootSample.java
@Configuration
public class RabbitMQSpringConfig {

    @Value("${tiw1.imprservice.queue}")
    private String jobQueueName;

    @Bean
    public Mono<Connection> connectionMono(RabbitProperties rabbitProperties) {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost(rabbitProperties.getHost());
        connectionFactory.setPort(rabbitProperties.getPort());
        connectionFactory.setUsername(rabbitProperties.getUsername());
        connectionFactory.setPassword(rabbitProperties.getPassword());
        return Mono.fromCallable(() -> connectionFactory.newConnection("reactor-rabbit")).cache();
    }

    @Bean
    public Receiver receiver(Mono<Connection> connectionMono) {
        return RabbitFlux.createReceiver(new ReceiverOptions().connectionMono(connectionMono));
    }

    @Bean
    public Flux<DemandeDTO> jobFlux(Receiver receiver, JobService jobService) {
        return receiver.consumeNoAck(jobQueueName)
                .flatMap(m -> jobService.parseDemande(m.getBody()));
    }
}
