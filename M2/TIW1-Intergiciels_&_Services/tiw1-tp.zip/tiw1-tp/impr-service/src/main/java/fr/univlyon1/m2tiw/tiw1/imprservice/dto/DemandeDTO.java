package fr.univlyon1.m2tiw.tiw1.imprservice.dto;

import java.util.UUID;

public class DemandeDTO {

    public UUID jobId;
    public long modele3DId;
    public String queue;

    public DemandeDTO() {
    }

    public DemandeDTO(UUID jobId, long modele3DId, String queue) {
        this.jobId = jobId;
        this.modele3DId = modele3DId;
        this.queue = queue;
    }

}
