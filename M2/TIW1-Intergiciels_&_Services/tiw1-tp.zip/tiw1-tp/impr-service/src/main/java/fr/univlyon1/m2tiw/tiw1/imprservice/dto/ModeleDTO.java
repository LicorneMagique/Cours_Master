package fr.univlyon1.m2tiw.tiw1.imprservice.dto;

public class ModeleDTO {
    public Long id;
    public String nom;
}
