package fr.univlyon1.m2tiw.tiw1.imprservice.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2tiw.tiw1.imprservice.dto.DemandeDTO;
import fr.univlyon1.m2tiw.tiw1.imprservice.dto.ModeleDTO;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Service
@Slf4j
public class JobService {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Value("${tiw1.imprservice.finImpression.queue}")
    private String queue;

    public Publisher<DemandeDTO> parseDemande(byte[] data) {
        try {
            return Mono.just(objectMapper.readValue(data, DemandeDTO.class));
        } catch (IOException e) {
            log.error("Could not parse job", e);
            return Mono.empty();
        }
    }

    public Flux<UUID> handleJobFlux(Flux<DemandeDTO> demandes) {
        return demandes.map(d -> {
            log.info("** Réception M7 **");
            String url = "http://localhost:8086/modele/" + d.modele3DId;
            WebClient client = WebClient.create(url);
            Mono<ModeleDTO> response = client.get().exchangeToMono(data ->
                data.statusCode().equals(HttpStatus.OK) ? data.bodyToMono(ModeleDTO.class) : null
            );
            log.info("** Envoi M8 **");
            ModeleDTO modele = response.block();
            if (modele == null) {
                log.error("Error job " + d.jobId);
                return null;
            }
            log.info("** Réception M8R **");
            // Simulation temps impression
            Long imprTime = ThreadLocalRandom.current().nextLong(5000, 11000);
            try {
                Thread.sleep(imprTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // Notif fin impression
            Queue queue = new Queue(this.queue);
            log.info("** Envoi M9 **");
            rabbitTemplate.convertAndSend(queue.getName(), d.jobId);
            return d.jobId;
        });
    }
}
