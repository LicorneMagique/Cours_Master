package fr.univlyon1.m2tiw.tiw1.imprservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImprServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
