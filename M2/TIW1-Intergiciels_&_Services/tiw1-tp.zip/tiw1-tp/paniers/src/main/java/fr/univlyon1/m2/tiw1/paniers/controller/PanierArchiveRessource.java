package fr.univlyon1.m2.tiw1.paniers.controller;

import fr.univlyon1.m2.tiw1.annotations.Controller;
import fr.univlyon1.m2.tiw1.annotations.Method;
import fr.univlyon1.m2.tiw1.annotations.RequestMapping;
import fr.univlyon1.m2.tiw1.paniers.dao.ArticleDAO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.dao.PanierDAO;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.paniers.services.dto.PanierDTO;
import fr.univlyon1.m2.tiw1.server.Response;
import org.slf4j.Logger;

import java.sql.SQLException;

@Controller(baseUrl = "panierArchive")
public class PanierArchiveRessource {

    protected PanierDAO panierDAO;
    protected ArticleDAO articleDAO;
    private final Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

    /**
     * Retourne la sérialisation (JSON) du panier demandé.
     */
    @RequestMapping(url = "", method = Method.GET)
    public Response<String> getPanier(Long id) {
        try {
            logger.info("** Réception M6 **");
            Panier panier = panierDAO.getPanier(id);
            panier.getArticles().addAll(articleDAO.getArticlesByPanier(id));
            panier.updateMontant();
            logger.info("** Envoi M6R **");
            return new Response<>(PanierDTO.fromPanier(panier).toJSON(), 200);
        } catch (SQLException e) {
            return new Response<>(e.getMessage(), 500);
        } catch (NotFoundException e) {
            return new Response<>(e.getMessage(), 404);
        }
    }
}
