package fr.univlyon1.m2.tiw1.paniers.controller;

import fr.univlyon1.m2.tiw1.annotations.Controller;
import fr.univlyon1.m2.tiw1.annotations.Method;
import fr.univlyon1.m2.tiw1.annotations.RequestMapping;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.services.EmptyPanierException;
import fr.univlyon1.m2.tiw1.paniers.services.InvalidArticleException;
import fr.univlyon1.m2.tiw1.paniers.services.Modele3DService;
import fr.univlyon1.m2.tiw1.paniers.services.PanierCourantService;
import fr.univlyon1.m2.tiw1.paniers.services.dto.Modele3DDTO;
import fr.univlyon1.m2.tiw1.paniers.services.dto.PanierDTO;
import fr.univlyon1.m2.tiw1.server.Response;
import org.slf4j.Logger;

import java.sql.SQLException;

@Controller(baseUrl = "panierCourant")
public class PanierCourantRessource {

    protected Modele3DService modele3DService;
    protected PanierCourantService panierCourantService;
    private final Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

    @RequestMapping(url = "", method = Method.GET)
    public Response<String> getPanierCourant() {
        return new Response<>(PanierDTO.fromPanier(panierCourantService.getPanierCourant()).toJSON(),  200);
    }

    @RequestMapping(url = "/modeles", method = Method.PUT)
    public Response<String> updatePanierCourant(Modele3DDTO modele3DDTO, Integer quantite) {
        try {
            Modele3D modele3D = modele3DService.getModele3D(modele3DDTO.getId());
            if (quantite > 0) {
                panierCourantService.ajouterModeles3D(modele3D, quantite);
            } else {
                panierCourantService.supprimerModeles3D(modele3D, -quantite);
            }
            PanierDTO content = PanierDTO.fromPanier(panierCourantService.getPanierCourant());
            return new Response<>(content.toJSON(), 204);
        } catch (NotFoundException e) {
            return new Response<>(404);
        } catch (InvalidArticleException e) {
            return new Response<>(400);
        }
    }

    /**
     * Ajoute un article au panier courant à partir de son modèle 3D.
     */
    @RequestMapping(url = "/modeles", method = Method.POST)
    public Response<String> addModel3D(Modele3DDTO modele3DDTO) {
        return updatePanierCourant(modele3DDTO, 1);
    }

    /**
     * Retire l'article demandé du panier courant à partir de son modèle 3D.
     */
    @RequestMapping(url = "/modeles", method = Method.DELETE)
    public Response<String> deleteModel3D(Modele3DDTO modele3DDTO) {
        return updatePanierCourant(modele3DDTO, -1);
    }

    /**
     * Valide le panier courant.
     */
    @RequestMapping(url = "", method = Method.POST)
    public Response<String> validatePanier(String email) {
        try {
            PanierDTO panier = PanierDTO.fromPanier(panierCourantService.validerPanierCourant(email));
            return new Response<>(panier.toJSON(), 200);
        } catch (EmptyPanierException e) {
            return new Response<>(e.getMessage(), 400);
        } catch (SQLException e) {
            return new Response<>(e.getMessage(), 500);
        }
    }

    // Pour les tests
    @RequestMapping(url = "create", method = Method.POST)
    public Response<String> create() {
        PanierDTO content = PanierDTO.fromPanier(panierCourantService.creerPanierCourant());
        return new Response<>(content.toJSON(), 200);
    }
}
