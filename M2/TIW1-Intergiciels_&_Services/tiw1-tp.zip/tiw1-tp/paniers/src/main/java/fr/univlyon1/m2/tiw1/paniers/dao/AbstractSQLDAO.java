package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.annotations.Persistence;
import fr.univlyon1.m2.tiw1.paniers.services.DBAccess;
import fr.univlyon1.m2.tiw1.server.Initiable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Shared init procedure for DAOs based on SQL.
 */
public abstract class AbstractSQLDAO implements Initiable {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractSQLDAO.class);
    protected DBAccess dBAccess;
    private Connection currentConnection = null;

    public void init() {
        Connection connection = null;
        try {
            connection = dBAccess.getConnection();
        if (currentConnection != connection) {
            LOG.debug("Initializing table and statements");
            setupTable(connection);
            initStatements(connection);
            currentConnection = connection;
        }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        LOG.debug("End of init");
    }

    /**
     * Initializes statements used for SQL queries.
     *
     * @param connection SQL connection to the DB
     * @throws SQLException if there is an error while creating statements
     */
    protected abstract void initStatements(Connection connection) throws SQLException;

    /**
     * Creates tables for storing DAO target entity.
     *
     * @param connection SQL connection to the DB
     * @throws SQLException if there is an error while creating tables
     */
    protected abstract void setupTable(Connection connection) throws SQLException;
}
