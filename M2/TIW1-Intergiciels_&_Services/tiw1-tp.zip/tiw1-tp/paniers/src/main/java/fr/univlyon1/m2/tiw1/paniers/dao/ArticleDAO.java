package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.server.Initiable;
import org.picocontainer.Startable;

import java.sql.SQLException;
import java.util.Collection;

/**
 * DAO for managing Article persistence.
 */
public interface ArticleDAO extends Initiable {

    void init();

    /**
     * Saves a new article in base
     *
     * @param article  the article to save
     * @param panierId the id of the panier the article will be in.
     * @return either the provided article or a copy with an updated id.
     * @throws SQLException if there is a persistence problem
     */
    Article saveArticle(Article article, long panierId) throws SQLException;

    /**
     * Retreives an article using its id.
     * This method retreives the corresponding modele3d.
     *
     * @param id the id of the article
     * @return the article
     * @throws NotFoundException if the id does not match an article in the persistence support
     * @throws SQLException      if there is a problem in the underlying queries
     */
    Article getArticleById(long id) throws NotFoundException, SQLException;

    /**
     * Retreive articles related to the given panier.
     * @param panierId the identifier for the panier
     * @return the collection of matching articles
     * @throws SQLException if there is a problem in DB.
     * @throws NotFoundException if a reference modele3d cannot be found
     */
    Collection<Article> getArticlesByPanier(long panierId) throws SQLException, NotFoundException;

    /**
     * Updates the data for an article
     *
     * @param article the article to update in the persistence support
     * @return the article or an updated copy
     * @throws NotFoundException if the article is not found in the persistence support
     * @throws SQLException      if there is a problem in the underlying queries
     */
    Article updateArticle(Article article) throws NotFoundException, SQLException;

    /**
     * Deletes an article.
     *
     * @param article the article to remove from the DB
     * @throws SQLException      if there is a problem in the underlying query
     * @throws NotFoundException if the article does not exist in DB
     */
    void deleteArticle(Article article) throws SQLException, NotFoundException;

}
