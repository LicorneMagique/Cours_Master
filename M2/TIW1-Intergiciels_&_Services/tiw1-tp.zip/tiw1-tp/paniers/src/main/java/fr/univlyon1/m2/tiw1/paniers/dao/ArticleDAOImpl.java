package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.annotations.Persistence;
import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.services.DBAccess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

@Persistence
public class ArticleDAOImpl extends AbstractSQLDAO implements ArticleDAO {

    private static final Logger LOG = LoggerFactory.getLogger(ArticleDAOImpl.class);

    protected Modele3DDAO modele3DDAO;
    private PreparedStatement insertStatement = null;
    private PreparedStatement getByIdStatement = null;
    private PreparedStatement updateStatement = null;
    private PreparedStatement deleteStatement = null;
    private PreparedStatement getByPanierStatement = null;

    public DBAccess getDBAccess() {
        return this.dBAccess;
    }

    @Override
    protected void setupTable(Connection connection) throws SQLException {
        Statement stat = connection.createStatement();
        stat.execute("CREATE TABLE IF NOT EXISTS article(" +
                "id SERIAL PRIMARY KEY, " +
                "id_modele3d INTEGER NOT NULL, " +
                "quantite INTEGER DEFAULT 1, " +
                "panier INTEGER NOT NULL REFERENCES panier(id)) ");
    }

    @Override
    protected void initStatements(Connection connection) throws SQLException {
        insertStatement = connection.prepareStatement("INSERT INTO article(id_modele3d, quantite, panier) VALUES (?,?,?) returning id");
        getByIdStatement = connection.prepareStatement("SELECT id_modele3d, quantite FROM article WHERE id = ?");
        getByPanierStatement = connection.prepareStatement("SELECT id, id_modele3d, quantite FROM article WHERE panier = ?");
        updateStatement = connection.prepareStatement("UPDATE article SET id_modele3d = ? , quantite = ? WHERE id = ?");
        deleteStatement = connection.prepareStatement("DELETE FROM article WHERE id = ?");
        LOG.debug("Prepared statements");
    }

    @Override
    public Article saveArticle(Article article, long panierId) throws SQLException {
        insertStatement.setLong(1, article.getModele3D().getId());
        insertStatement.setInt(2, article.getQuantite());
        insertStatement.setLong(3, panierId);
        ResultSet rs = insertStatement.executeQuery();
        if (rs.next()) {
            article.setId(rs.getLong(1));
            return article;
        } else {
            throw new SQLException("Failed to create article");
        }
    }

    @Override
    public Article getArticleById(long id) throws NotFoundException, SQLException {
        getByIdStatement.setLong(1, id);
        ResultSet rs = getByIdStatement.executeQuery();
        if (rs.next()) {
            return new Article(id, modele3DDAO.getModele3D(rs.getLong(1)), rs.getInt(2));
        } else {
            throw new NotFoundException();
        }
    }

    @Override
    public Collection<Article> getArticlesByPanier(long panierId) throws SQLException, NotFoundException {
        Collection<Article> result = new ArrayList<>();
        getByPanierStatement.setLong(1, panierId);
        ResultSet rs = getByPanierStatement.executeQuery();
        while (rs.next()) {
            result.add(new Article(rs.getLong(1),
                    modele3DDAO.getModele3D(rs.getLong(2)),
                    rs.getInt(3)));
        }
        return result;
    }

    @Override
    public Article updateArticle(Article article) throws NotFoundException, SQLException {
        // remarque on ne met pas à jour le panier
        updateStatement.setLong(3, article.getId());
        updateStatement.setLong(1, article.getModele3D().getId());
        updateStatement.setInt(2, article.getQuantite());
        int count = updateStatement.executeUpdate();
        if (count < 1) {
            throw new NotFoundException("article " + article.getId() + " not updated");
        } else if (count > 1) {
            throw new SQLException("Duplicate article " + article.getId() + " in DB");
        }
        return article;
    }

    @Override
    public void deleteArticle(Article article) throws SQLException, NotFoundException {
        deleteStatement.setLong(1, article.getId());
        int count = deleteStatement.executeUpdate();
        if (count < 1) {
            throw new NotFoundException("Article " + article.getId() + " to delete was not found");
        }
    }

    @Override
    public void init() {
        LOG.debug(getClass().getName() + " call super.init()");
        super.init();
    }
}
