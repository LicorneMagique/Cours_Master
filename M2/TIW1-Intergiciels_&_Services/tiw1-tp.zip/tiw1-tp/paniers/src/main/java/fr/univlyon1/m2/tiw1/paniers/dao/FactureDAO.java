package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Facture;

public interface FactureDAO {
    public Facture saveFacture(Facture facture) throws MaxFacturesException;
    public Facture getFacture(Long id) throws NotFoundException, MaxFacturesException;
    public void releaseFacture(Long id) throws NotFoundException;
}
