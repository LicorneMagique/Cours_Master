package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Facture;

import java.util.HashMap;
import java.util.Map;

public class FactureDAOImpl implements FactureDAO {

    private static final Map<Long, Facture> factures = new HashMap<>();
    private static Long lastId = 0L;

    @Override
    public Facture saveFacture(Facture facture) {
        facture.setId(++lastId);
        factures.put(facture.getId(), facture);
        return facture;
    }

    @Override
    public Facture getFacture(Long id) throws NotFoundException {
        if (factures.containsKey(id)) {
            return factures.get(id);
        }
        throw new NotFoundException(String.format("Facture %d doesn't exist", id));
    }

    @Override
    public void releaseFacture(Long id) {
    }
}
