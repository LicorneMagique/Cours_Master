package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.annotations.Persistence;
import fr.univlyon1.m2.tiw1.paniers.model.Facture;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Persistence(params = {"MAX_FACTURES", "12"})
public class FactureDAOPool implements FactureDAO {

    private static final Map<Long, Facture> factures = new HashMap<>();
    private static Long lastId = 0L;

    protected static Integer MAX_FACTURES;
    private final List<Facture> freeFactures;
    private final List<Facture> releasedFactures;

    public FactureDAOPool() {
        this.freeFactures = new ArrayList<>();
        this.releasedFactures = new ArrayList<>();
    }

    @Override
    public Facture saveFacture(Facture facture) throws MaxFacturesException {
        if (freeFactures.size() == MAX_FACTURES) {
            throw new MaxFacturesException();
        }
        facture.setId(++lastId);
        factures.put(facture.getId(), facture);
        freeFactures.add(facture);
        return facture;
    }

    @Override
    public Facture getFacture(Long id) throws NotFoundException, MaxFacturesException {
        if (!factures.containsKey(id)) {
            throw new NotFoundException(String.format("Facture %d doesn't exist", id));
        }
        Facture facture = factures.get(id);
        if (freeFactures.contains(facture)) { // Cas 1 : La facture est libre.
            return facture;
        }
        // Cas 2 et 3 : La facture n'est pas libre…
        if (freeFactures.size() < MAX_FACTURES) { // Cas 2 : … mais il reste de la place.
            facture.initTemplate();
            releasedFactures.remove(facture);
            freeFactures.add(facture);
        }
        throw new MaxFacturesException(); // Cas 3 : … et il ne reste plus de place.
    }

    @Override
    public void releaseFacture(Long id) throws NotFoundException {
        if (!factures.containsKey(id)) {
            throw new NotFoundException(String.format("Facture %d doesn't exist", id));
        }
        Facture facture = factures.get(id);
        facture.cleanTemplate();
        if (releasedFactures.contains(facture)) { // Déjà relâchée
            return;
        }
        freeFactures.remove(facture);
        releasedFactures.add(facture);
    }
}
