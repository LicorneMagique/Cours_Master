package fr.univlyon1.m2.tiw1.paniers.dao;

public class MaxFacturesException extends Exception {
    public MaxFacturesException() {
        super();
    }

    public MaxFacturesException(String message) {
        super(message);
    }

    public MaxFacturesException(String message, Throwable cause) {
        super(message, cause);
    }

    public MaxFacturesException(Throwable cause) {
        super(cause);
    }

    protected MaxFacturesException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
