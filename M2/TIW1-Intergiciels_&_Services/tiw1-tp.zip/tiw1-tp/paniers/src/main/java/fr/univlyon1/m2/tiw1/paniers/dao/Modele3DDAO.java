package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;

/**
 * Manages persistence of modele3d.
 */
public interface Modele3DDAO {

    /**
     * Get a modele3d from persistence support
     *
     * @param id the id of the modele3d
     * @return the modele3d
     * @throws NotFoundException if the modele3d was not in the persistence support.
     */
    Modele3D getModele3D(long id) throws NotFoundException;
}
