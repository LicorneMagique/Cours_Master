package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.annotations.Persistence;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;

import java.util.HashMap;
import java.util.Map;

@Persistence
public class Modele3DDAOMock implements Modele3DDAO {

    private final Map<Long, Modele3D> modeles3D = new HashMap<>();
    private static long nameGen = 0L;

    public Modele3DDAOMock() {
        // Création des données mockées
        for (int i = 0; i < 5; i++) {
            getModele3D(i);
        }
    }

    @Override
    public Modele3D getModele3D(long id) {
        if (modeles3D.containsKey(id)) {
            return modeles3D.get(id);
        } else {
            Modele3D modele3D = new Modele3D(id, "Modele_" + (nameGen++));
            modeles3D.put(id, modele3D);
            return modele3D;
        }
    }
}
