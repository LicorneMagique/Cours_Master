package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.server.Initiable;

import java.sql.SQLException;

/**
 * Manages persistence of panier
 */
public interface PanierDAO extends Initiable {

    void init();

    /**
     * Saves a panier in the persistence support.
     *
     * @param panier the panier to save
     * @return the panier or an updated copy
     * @throws SQLException if the is a problem in DB
     */
    Panier savePanier(Panier panier) throws SQLException;

    /**
     * Retreives a panier from its id.
     *
     * @param panierId the id of the panier to retreive
     * @return the panier
     * @throws SQLException      if there is a problem in the DB
     * @throws NotFoundException if the panier is not in DB
     */
    Panier getPanier(long panierId) throws SQLException, NotFoundException;

    /**
     * Updates a panier in DB
     *
     * @param panier the panier to update
     * @throws SQLException      if there is a problem in DB
     * @throws NotFoundException if the panier is not in DB
     */
    void updatePanier(Panier panier) throws SQLException, NotFoundException;
}
