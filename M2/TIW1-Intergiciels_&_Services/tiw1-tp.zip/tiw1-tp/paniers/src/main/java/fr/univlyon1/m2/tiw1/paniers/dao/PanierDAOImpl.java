package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.annotations.Persistence;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

@Persistence
public class PanierDAOImpl extends AbstractSQLDAO implements PanierDAO {

    private final static Logger LOG = LoggerFactory.getLogger(PanierDAOImpl.class);
    private PreparedStatement insertStatement;
    private PreparedStatement getStatement;
    private PreparedStatement updateStatement;

    public PanierDAOImpl() {
        super();
    }

    @Override
    protected void initStatements(Connection connection) throws SQLException {
        insertStatement = connection.prepareStatement(
                "INSERT INTO panier(courant, email) VALUES(?, ?) RETURNING id");
        getStatement = connection.prepareStatement(
                "SELECT courant, email FROM panier WHERE id = ?");
        updateStatement = connection.prepareStatement(
                "UPDATE panier set courant = ?, email = ? WHERE id = ?");
        LOG.debug("Statements prepared");
    }

    @Override
    protected void setupTable(Connection connection) throws SQLException {
        Statement stat = connection.createStatement();
        stat.execute("CREATE TABLE IF NOT EXISTS panier(" +
                "id SERIAL PRIMARY KEY," +
                "courant BOOLEAN," +
                "email VARCHAR) ");
    }

    @Override
    public Panier savePanier(Panier panier) throws SQLException {
        insertStatement.setBoolean(1, panier.isFerme());
        insertStatement.setString(2, panier.getEmail());
        ResultSet rs = insertStatement.executeQuery();
        if (rs.next()) {
            panier.setNumP(rs.getLong(1));
            return panier;
        } else {
            throw new SQLException("Failed to create panier");
        }
    }

    @Override
    public Panier getPanier(long panierId) throws SQLException, NotFoundException {
        getStatement.setLong(1, panierId);
        ResultSet rs = getStatement.executeQuery();
        if (rs.next()) {
            Panier panier = new Panier(rs.getBoolean(1), 0.0, new ArrayList<>(), null);
            panier.setNumP(panierId);
            panier.setEmail(rs.getString(2));
            return panier;
        } else {
            throw new NotFoundException("Panier " + panierId + " not found in DB");
        }
    }

    @Override
    public void updatePanier(Panier panier) throws SQLException, NotFoundException {
        updateStatement.setBoolean(1, panier.isFerme());
        updateStatement.setString(2, panier.getEmail());
        updateStatement.setLong(3, panier.getNumP());
        int count = updateStatement.executeUpdate();
        if (count < 1) {
            throw new NotFoundException("Panier " + panier.getNumP() + " cannot be found to be updated");
        }
    }

    @Override
    public void init() {
        LOG.debug(getClass().getName() + " call super.init()");
        super.init();
    }
}
