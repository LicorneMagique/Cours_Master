package fr.univlyon1.m2.tiw1.paniers.model;

import java.util.Objects;

public class Article {

    private Long id;
    private Modele3D modele3D;
    private Integer quantite;

    public Article() {
    }

    public Article(Long id, Modele3D modele3D, Integer quantite) {
        this.id = id;
        this.modele3D = modele3D;
        this.quantite = quantite;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Article article = (Article) o;
        return Objects.equals(id, article.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Modele3D getModele3D() {
        return modele3D;
    }

    public void setModele3D(Modele3D modele3D) {
        this.modele3D = modele3D;
    }

    public Integer getQuantite() {
        return quantite;
    }

    public void setQuantite(Integer quantite) {
        this.quantite = quantite;
    }
}
