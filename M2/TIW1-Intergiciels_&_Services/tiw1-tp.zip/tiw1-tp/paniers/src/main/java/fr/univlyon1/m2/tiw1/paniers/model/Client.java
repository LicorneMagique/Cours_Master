package fr.univlyon1.m2.tiw1.paniers.model;

import java.util.Objects;

public class Client {

    private Long id;
    private String caption; // Nom - prénom - entreprise - whateveryouwant
    private static Long lastId = 0L;

    public Client(String caption) {
        this.id = ++lastId;
        this.caption = caption;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return Objects.equals(id, client.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }
}
