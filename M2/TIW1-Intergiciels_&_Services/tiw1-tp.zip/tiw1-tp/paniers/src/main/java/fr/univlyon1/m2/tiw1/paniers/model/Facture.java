package fr.univlyon1.m2.tiw1.paniers.model;

import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheFactory;

import java.io.StringWriter;
import java.util.Objects;

public class Facture {

    private Long id;
    private Panier panier;
    private Client client;
    private Mustache template;

    public Facture() {
        initTemplate();
    }

    public void initTemplate() {
        MustacheFactory mf = new DefaultMustacheFactory();
        this.template = mf.compile("facture.mustache");
    }

    public void cleanTemplate() {
        this.template = null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Facture facture = (Facture) o;
        return Objects.equals(id, facture.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Panier getPanier() {
        return panier;
    }

    public void setPanier(Panier panier) {
        this.panier = panier;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Mustache getTemplate() {
        return template;
    }

    public String print() {
        StringWriter htmlWriter = new StringWriter();
        template.execute(htmlWriter, this);
        return htmlWriter.toString();
    }
}
