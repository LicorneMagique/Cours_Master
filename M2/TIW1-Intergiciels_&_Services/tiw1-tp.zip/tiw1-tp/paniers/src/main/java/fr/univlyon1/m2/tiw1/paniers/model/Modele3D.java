package fr.univlyon1.m2.tiw1.paniers.model;

import java.util.Objects;

public class Modele3D {

    private Long id;
    private String nom;

    public Modele3D() {
    }

    public Modele3D(Long id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Modele3D modele3D = (Modele3D) o;
        return Objects.equals(id, modele3D.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
