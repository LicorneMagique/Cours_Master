package fr.univlyon1.m2.tiw1.paniers.model;

import java.util.Collection;
import java.util.Objects;

public class Panier {

    private Long numP; // Set par le DAO
    private Boolean ferme;
    private Double montant;
    private Collection<Article> articles;
    private String idCompteBanque;
    private String email;

    public Panier(Boolean ferme, Double montant, Collection<Article> articles, String idCompteBanque) {
        this.ferme = ferme;
        this.montant = montant;
        this.articles = articles;
        this.idCompteBanque = idCompteBanque;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Panier panier = (Panier) o;
        return Objects.equals(numP, panier.numP);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numP);
    }

    public Long getNumP() {
        return numP;
    }

    public void setNumP(Long numP) {
        this.numP = numP;
    }

    public boolean isFerme() {
        return ferme;
    }

    public void setFerme(boolean ferme) {
        this.ferme = ferme;
    }

    public Boolean getFerme() {
        return ferme;
    }

    public void setFerme(Boolean ferme) {
        this.ferme = ferme;
    }

    public Double getMontant() {
        return montant;
    }

    public void setMontant(Double montant) {
        this.montant = montant;
    }

    public Collection<Article> getArticles() {
        return articles;
    }

    public void setArticles(Collection<Article> articles) {
        this.articles = articles;
    }

    public String getIdCompteBanque() {
        return idCompteBanque;
    }

    public void setIdCompteBanque(String idCompteBanque) {
        this.idCompteBanque = idCompteBanque;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void updateMontant() {
        montant = 0.0;
        articles.forEach(article -> montant += article.getQuantite() * 5.0);
    }
}
