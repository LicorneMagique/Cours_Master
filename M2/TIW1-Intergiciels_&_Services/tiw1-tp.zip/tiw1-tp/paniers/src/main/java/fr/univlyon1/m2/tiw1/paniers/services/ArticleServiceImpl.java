package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.annotations.Service;
import fr.univlyon1.m2.tiw1.paniers.dao.ArticleDAO;
import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;

import java.sql.SQLException;

@Service
public class ArticleServiceImpl implements ArticleService {

    private static Long currentId = 0L;
    protected ArticleDAO articleDAO;

    @Override
    public Article creerArticle(Modele3D modele3D, int quantite) {
        return new Article(currentId++, modele3D, quantite);
    }

    @Override
    public void modifierArticle(Article article, Modele3D modele3D, int quantite) throws InvalidArticleException {
        if(!article.getModele3D().equals(modele3D))
            throw new InvalidArticleException("Modele3D errone");
        if(article.getQuantite() + quantite < 0)
            throw new InvalidArticleException("Quantite insuffisante");
        article.setQuantite(article.getQuantite() + quantite);
    }

    @Override
    public void sauverArticle(Article article, Panier panier) throws SQLException {
        articleDAO.saveArticle(article, panier.getNumP());
    }
}
