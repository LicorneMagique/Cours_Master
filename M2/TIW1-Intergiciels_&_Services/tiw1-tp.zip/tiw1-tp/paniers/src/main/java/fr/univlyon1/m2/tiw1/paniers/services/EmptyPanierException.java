package fr.univlyon1.m2.tiw1.paniers.services;

public class EmptyPanierException extends Exception {
    public EmptyPanierException() {
        super();
    }

    public EmptyPanierException(String message) {
        super(message);
    }

    public EmptyPanierException(String message, Throwable cause) {
        super(message, cause);
    }

    public EmptyPanierException(Throwable cause) {
        super(cause);
    }

    protected EmptyPanierException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
