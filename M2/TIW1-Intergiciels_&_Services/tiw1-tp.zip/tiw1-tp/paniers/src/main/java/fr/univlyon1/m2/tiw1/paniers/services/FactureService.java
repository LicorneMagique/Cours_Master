package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.dao.MaxFacturesException;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.model.Client;
import fr.univlyon1.m2.tiw1.paniers.model.Facture;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;

public interface FactureService {
    Facture createFacture(Client client, Panier panier) throws MaxFacturesException;
    Facture getFacture(Long id) throws NotFoundException, MaxFacturesException;
    String printFacture(Long id) throws NotFoundException, MaxFacturesException;
    void releaseFacture(Long id) throws NotFoundException;
}
