package fr.univlyon1.m2.tiw1.paniers.services;

public class InvalidArticleException extends Exception {
    public InvalidArticleException() {
        super();
    }

    public InvalidArticleException(String message) {
        super(message);
    }

    public InvalidArticleException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidArticleException(Throwable cause) {
        super(cause);
    }

    protected InvalidArticleException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
