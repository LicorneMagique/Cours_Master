package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;

import java.util.List;

public interface Modele3DService {
    public List<Modele3D> getAllModeles3D();
    public Modele3D getModele3D(Long id) throws NotFoundException;
}
