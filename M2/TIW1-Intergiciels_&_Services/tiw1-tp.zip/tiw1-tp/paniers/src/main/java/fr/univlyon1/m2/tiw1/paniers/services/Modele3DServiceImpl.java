package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.annotations.Service;
import fr.univlyon1.m2.tiw1.paniers.dao.Modele3DDAO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

@Service
public class Modele3DServiceImpl implements Modele3DService {

    private static final Logger LOG = LoggerFactory.getLogger(Modele3DServiceImpl.class);
    protected Modele3DDAO modele3DDAO;

    @Override
    public List<Modele3D> getAllModeles3D() {
        List<Modele3D> modeles3D = new ArrayList<>();
        for (Long i = 0L; i < 10L; i++) {
            try {
                modeles3D.add(getModele3D(i));
            } catch (NotFoundException e) {
                LOG.error("Modele3D {} not found", i);
            }
        }
        return modeles3D;
    }

    @Override
    public Modele3D getModele3D(Long id) throws NotFoundException {
        return modele3DDAO.getModele3D(id);
    }
}
