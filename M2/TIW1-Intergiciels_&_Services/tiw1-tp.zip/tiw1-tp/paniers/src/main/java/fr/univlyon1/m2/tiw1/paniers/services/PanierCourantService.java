package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;

import java.sql.SQLException;
import java.util.Collection;

public interface PanierCourantService {
    public Panier creerPanierCourant();
    public void ajouterModeles3D(Modele3D modele3D, int quantite);
    public void supprimerModeles3D(Modele3D modele3D, int quantite) throws InvalidArticleException;
    public Collection<Article> getAllArticles();
    public Panier validerPanierCourant(String email) throws EmptyPanierException, SQLException;
    public Panier getPanierCourant();
}
