package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.annotations.Service;
import fr.univlyon1.m2.tiw1.paniers.dao.PanierDAO;
import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import org.slf4j.Logger;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

@Service
public class PanierCourantServiceImpl implements PanierCourantService {

    private Panier panierCourant;
    private Long articleId = 0L;
    protected PanierDAO panierDAO;
    protected ArticleService articleService;
    private final Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

    @Override
    public Panier creerPanierCourant() {
        panierCourant = new Panier(false, 0.0, new ArrayList<>(), "imprbank-23456788");
        return panierCourant;
    }

    @Override
    public void ajouterModeles3D(Modele3D modele3D, int quantite) {
        if (panierCourant == null) {
            creerPanierCourant();
        }
        Article articleModele3D = null;
        for (Article article : panierCourant.getArticles()) {
            if (article.getModele3D().equals(modele3D)) {
                articleModele3D = article;
                articleModele3D.setQuantite(articleModele3D.getQuantite() + quantite);
            }
        }
        if (articleModele3D == null) {
            articleModele3D = new Article(articleId++, modele3D, quantite);
            panierCourant.getArticles().add(articleModele3D);
        }
        panierCourant.updateMontant();
    }

    @Override
    public void supprimerModeles3D(Modele3D modele3D, int quantite) throws InvalidArticleException {
        Article aSupprimer = null;
        for (Article article : panierCourant.getArticles()) {
            if (article.getModele3D().equals(modele3D)) {
                if (article.getQuantite() < quantite)
                    throw new InvalidArticleException("Quantite insuffisante");
                article.setQuantite(article.getQuantite() - quantite);
                if (article.getQuantite() == 0) {
                    aSupprimer = article;
                }
                break;
            }
        }
        if (aSupprimer != null) {
            panierCourant.getArticles().remove(aSupprimer);
        }
        panierCourant.updateMontant();
    }

    @Override
    public Collection<Article> getAllArticles() {
        return panierCourant.getArticles();
    }

    @Override
    public Panier validerPanierCourant(String email) throws EmptyPanierException, SQLException {
        if (panierCourant.getArticles().size() == 0) {
            throw new EmptyPanierException("Panier vide");
        }
        logger.info("** Réception M1 **");
        panierCourant.setFerme(true);
        panierCourant.setEmail(email);
        panierCourant = panierDAO.savePanier(panierCourant);
        for (Article article : panierCourant.getArticles()) {
            articleService.sauverArticle(article, panierCourant);
        }
        Panier panierValide = panierCourant;
        creerPanierCourant(); // On repart avec un nouveau panier vide
        notifyImprBack(panierValide.getNumP());
        logger.info("** Envoi M1R **");
        return panierValide;
    }

    private void notifyImprBack(Long numP) {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setHost("localhost");
        connectionFactory.setPort(5672);
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        var rabbitAdmin = new RabbitAdmin(connectionFactory);
        Queue notif = new Queue("panier");
        rabbitAdmin.declareQueue(notif);
        logger.info("** Envoi M2 **");
        rabbitTemplate.convertAndSend(notif.getName(), numP);
    }

    @Override
    public Panier getPanierCourant() {
        if (panierCourant == null) {
            return creerPanierCourant();
        }
        return panierCourant;
    }
}
