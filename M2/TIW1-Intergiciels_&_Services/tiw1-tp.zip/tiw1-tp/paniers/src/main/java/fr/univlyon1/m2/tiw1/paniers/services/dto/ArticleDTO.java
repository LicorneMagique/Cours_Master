package fr.univlyon1.m2.tiw1.paniers.services.dto;

import fr.univlyon1.m2.tiw1.paniers.model.Article;
import org.json.JSONObject;

public class ArticleDTO {

    private Long id;
    private Long modele3DId;
    private int quantite;

    public ArticleDTO() {
    }

    public ArticleDTO(long modele3DId, int quantite) {
        this.modele3DId = modele3DId;
        this.quantite = quantite;
    }

    public static ArticleDTO fromArticle(Article article) {
        ArticleDTO articleDTO = new ArticleDTO();
        articleDTO.setId(article.getId());
        articleDTO.setModele3DId(article.getModele3D().getId());
        articleDTO.setQuantite(article.getQuantite());
        return articleDTO;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getModele3DId() {
        return modele3DId;
    }

    public void setModele3DId(Long modele3DId) {
        this.modele3DId = modele3DId;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public String toJSON() {
        return new JSONObject(this).toString();
    }
}
