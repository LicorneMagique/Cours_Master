package fr.univlyon1.m2.tiw1.paniers.services.dto;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;

public class Modele3DDTO {

    private Long id;
    private String nom;

    public Modele3DDTO() {
    }

    public Modele3DDTO(Long id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    public static Modele3DDTO fromModele(Modele3D modele3D) {
        Modele3DDTO modele3DDTO = new Modele3DDTO();
        modele3DDTO.setId(modele3D.getId());
        modele3DDTO.setNom(modele3D.getNom());
        return modele3DDTO;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String toJSON() {
        try {
            return new ObjectMapper().writeValueAsString(this);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }
}
