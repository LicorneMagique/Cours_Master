package fr.univlyon1.m2.tiw1.paniers.services.dto;

import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import org.json.JSONObject;

import java.util.Collection;
import java.util.stream.Collectors;

public class PanierDTO {

    private Long numP;
    private Boolean ferme;
    private Double montant;
    private Collection<ArticleDTO> articles;
    private String idCompteBanque;
    private String email;

    public PanierDTO() {}

    public PanierDTO(Long numP, Boolean ferme, Double montant, Collection<ArticleDTO> articles, String idCompteBanque, String email) {
        this.numP = numP;
        this.montant = montant;
        this.ferme = ferme;
        this.articles = articles;
        this.idCompteBanque = idCompteBanque;
        this.email = email;
    }

    public static PanierDTO fromPanier(Panier panier) {
        return new PanierDTO(
                panier.getNumP(),
                panier.isFerme(),
                panier.getMontant(),
                panier.getArticles().stream()
                        .map(ArticleDTO::fromArticle)
                        .collect(Collectors.toList()),
                panier.getIdCompteBanque(),
                panier.getEmail()
        );
    }

    public Long getNumP() {
        return numP;
    }

    public void setNumP(Long numP) {
        this.numP = numP;
    }

    public boolean isFerme() {
        return ferme;
    }

    public void setFerme(boolean ferme) {
        this.ferme = ferme;
    }

    public Collection<ArticleDTO> getArticles() {
        return articles;
    }

    public void setArticles(Collection<ArticleDTO> articles) {
        this.articles = articles;
    }

    public String toJSON() {
        return new JSONObject(this).toString();
    }

    public Double getMontant() {
        return montant;
    }

    public void setMontant(Double montant) {
        this.montant = montant;
    }

    public String getIdCompteBanque() {
        return idCompteBanque;
    }

    public void setIdCompteBanque(String idCompteBanque) {
        this.idCompteBanque = idCompteBanque;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
