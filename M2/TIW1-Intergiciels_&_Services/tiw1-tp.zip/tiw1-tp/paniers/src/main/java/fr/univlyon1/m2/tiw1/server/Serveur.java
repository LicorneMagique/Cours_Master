package fr.univlyon1.m2.tiw1.server;

import java.util.Map;

public interface Serveur {
    Object processRequest(String controlleur, String methode, Map<String, Object> parametres);
}
