package fr.univlyon1.m2.tiw1.server;

import fr.univlyon1.m2.tiw1.annotations.Server;
import org.picocontainer.MutablePicoContainer;

import java.util.Map;

@Server(applicationName = "Gestion RDP")
public class ServeurImpl implements Serveur {

    private final MutablePicoContainer picoContainer;
    private final ContextService contextService;

    public ServeurImpl() {
        this.picoContainer = Pico.getPicoContainer();
        this.contextService = picoContainer.getComponent(ContextService.class);
    }

    @Override
    public Object processRequest(String controlleur, String methode, Map<String, Object> parametres) {
        switch(controlleur) {
            case "panierCourant":
                return ((Controller) contextService.getComponent("/application/PanierCourantRessource")).process(methode, parametres);
            case "panierArchive":
                return ((Controller) contextService.getComponent("/application/PanierArchiveRessource")).process(methode, parametres);
        }
        return null; // Impossible à atteindre
    }
}
