package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.paniers.services.DBAccess;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.ServeurImplTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ArticleDAOTests {

    private ArticleDAO articleDAO;
    private Modele3DDAO modele3DDAO;
    private PanierDAO panierDAO;
    private Modele3D modele3D_1;
    private Modele3D modele3D_2;
    private Panier panier;

    @BeforeEach
    public void setup() throws NotFoundException, SQLException {
        ServeurImplTest.getServeur();
        this.modele3DDAO = (Modele3DDAO) Annuaire.getInstance().lookup("/application/persistence/Modele3DDAO");
        this.panierDAO = (PanierDAO) Annuaire.getInstance().lookup("/application/persistence/PanierDAO");
        this.articleDAO = (ArticleDAO) Annuaire.getInstance().lookup("/application/persistence/ArticleDAO");
        this.modele3D_1 = modele3DDAO.getModele3D(1);
        this.modele3D_2 = modele3DDAO.getModele3D(2);
        this.panier = new Panier(false, 0.0, null, null);
        this.panierDAO.savePanier(panier);
    }

    private int countArticles() throws SQLException {
        DBAccess dBAccess = (DBAccess) Annuaire.getInstance().lookup("/application/persistence/DBAccess");
        var rs = dBAccess.getConnection().createStatement().executeQuery(
                "SELECT COUNT(*) FROM article");
        rs.next();
        return rs.getInt(1);
    }

    @Test
    public void testSave() throws SQLException {
        int cur = countArticles();
        Article a = new Article();
        a.setModele3D(modele3D_1);
        a.setQuantite(2);
        articleDAO.saveArticle(a, panier.getNumP());
        assertEquals(cur + 1, countArticles());
    }

    @Test
    public void testGetArticleById() throws SQLException, NotFoundException {
        Article article = new Article(null, modele3D_1, 2);
        article = articleDAO.saveArticle(article, panier.getNumP());
        Article article2 = articleDAO.getArticleById(article.getId());
        assertEquals(article.getId(), article2.getId());
        assertEquals(article.getModele3D(), article2.getModele3D());
        assertEquals(article.getQuantite(), article2.getQuantite());
    }

    @Test
    public void testUpdateArticle() throws SQLException, NotFoundException {
        Article article = new Article(null, modele3D_1, 2);
        article = articleDAO.saveArticle(article, panier.getNumP());
        article.setQuantite(6);
        articleDAO.updateArticle(article);
        Article article2 = articleDAO.getArticleById(article.getId());
        assertEquals(6, article2.getQuantite());
    }

    @Test
    public void testDeleteArticle() throws SQLException, NotFoundException {
        Article article = new Article(null, modele3D_1, 2);
        article = articleDAO.saveArticle(article, panier.getNumP());
        int cur = countArticles();
        articleDAO.deleteArticle(article);
        assertEquals(cur - 1, countArticles());
    }

    @Test
    public void getByPanierIdTest() throws SQLException, NotFoundException {
        Article article1 = new Article(null, modele3D_1, 2);
        article1 = articleDAO.saveArticle(article1, panier.getNumP());
        Article article2 = new Article(null, modele3D_2, 5);
        article2 = articleDAO.saveArticle(article2, panier.getNumP());
        Collection<Article> articles = articleDAO.getArticlesByPanier(panier.getNumP());
        assertEquals(2, articles.size());
        assertTrue(articles.contains(article1));
        assertTrue(articles.contains(article2));
    }
}
