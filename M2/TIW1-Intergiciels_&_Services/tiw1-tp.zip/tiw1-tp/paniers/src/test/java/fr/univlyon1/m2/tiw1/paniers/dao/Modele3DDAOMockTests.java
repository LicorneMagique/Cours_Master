package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Modele3DDAOMockTests {
    @Test
    public void cacheTest() {
        Modele3DDAOMock modele3DDAOMock = new Modele3DDAOMock();
        Modele3D modele3D = modele3DDAOMock.getModele3D(3L);
        assertEquals(modele3D.getNom(), modele3DDAOMock.getModele3D(modele3D.getId()).getNom());
    }
}
