package fr.univlyon1.m2.tiw1.paniers.dao;

import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.paniers.services.DBAccess;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.ServeurImplTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PanierDAOTests {

    private DBAccess dBAccess;
    private PanierDAO panierDAO;

    @BeforeEach
    public void setup() {
        ServeurImplTest.getServeur();
        this.dBAccess = (DBAccess) Annuaire.getInstance().lookup("/application/persistence/DBAccess");
        this.panierDAO = (PanierDAO) Annuaire.getInstance().lookup("/application/persistence/PanierDAO");
    }

    private int countPaniers() throws SQLException {
        Statement stat = dBAccess.getConnection().createStatement();
        ResultSet rs = stat.executeQuery("SELECT COUNT(*) FROM panier");
        if (rs.next()) {
            return rs.getInt(1);
        } else {
            throw new SQLException("Could not count panier");
        }
    }

    @Test
    public void testSave() throws SQLException {
        int cur = countPaniers();
        Panier panier = new Panier(false, 0.0, null, null);
        panier.setFerme(true);
        panierDAO.savePanier(panier);
        assertEquals(cur + 1, countPaniers());
    }

    @Test
    public void testGet() throws SQLException, NotFoundException {
        Panier panier = new Panier(false, 0.0, null, null);
        panier = panierDAO.savePanier(panier);
        Panier panier2 = panierDAO.getPanier(panier.getNumP());
        assertEquals(panier.getNumP(), panier2.getNumP());
        assertEquals(panier.isFerme(), panier2.isFerme());
    }

    @Test
    public void testUpdate() throws SQLException, NotFoundException {
        Panier panier = new Panier(true, 0.0, null, null);
        panier = panierDAO.savePanier(panier);
        panier.setFerme(false);
        panierDAO.updatePanier(panier);
        Panier panier2 = panierDAO.getPanier(panier.getNumP());
        assertEquals(panier.getNumP(), panier2.getNumP());
        assertEquals(panier.isFerme(), panier2.isFerme());
    }
}
