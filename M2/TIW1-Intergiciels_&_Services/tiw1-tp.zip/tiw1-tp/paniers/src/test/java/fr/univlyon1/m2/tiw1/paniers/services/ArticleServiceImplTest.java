package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.paniers.dao.Modele3DDAO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.dao.PanierDAO;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.ServeurImplTest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ArticleServiceImplTest {

    private ArticleService articleService;
    private Modele3DDAO modele3DDAO;
    private PanierDAO panierDAO;
    private DBAccess dBAccess;

    @BeforeEach
    void setUp() {
        ServeurImplTest.getServeur();
        this.articleService = (ArticleService) Annuaire.getInstance().lookup("/application/service/ArticleService");
        this.modele3DDAO = (Modele3DDAO) Annuaire.getInstance().lookup("/application/persistence/Modele3DDAO");
        this.dBAccess = (DBAccess) Annuaire.getInstance().lookup("/application/persistence/DBAccess");
        this.panierDAO = (PanierDAO) Annuaire.getInstance().lookup("/application/persistence/PanierDAO");
    }

    @AfterEach
    void tearDown() {
    }

    private int countArticles() throws SQLException {
        var rs = dBAccess.getConnection().createStatement().executeQuery(
                "SELECT COUNT(*) FROM article");
        rs.next();
        return rs.getInt(1);
    }

    @Test
    void creerArticle() throws NotFoundException {
        Modele3D modele3D = modele3DDAO.getModele3D(1L);
        Article article = articleService.creerArticle(modele3D, 3);
        assertEquals(3, article.getQuantite());
        assertEquals(modele3D, article.getModele3D());
    }

    @Test
    void modifierArticle() throws InvalidArticleException, NotFoundException {
        Modele3D modele3D = modele3DDAO.getModele3D(2L);
        Article article = articleService.creerArticle(modele3D, 3);
        articleService.modifierArticle(article, modele3D, 2);
        assertEquals(2 + 3, article.getQuantite());
    }

    @Test
    void sauverArticle() throws SQLException, NotFoundException {
        int cur = countArticles();
        Modele3D modele3D = modele3DDAO.getModele3D(2L);
        Article article = articleService.creerArticle(modele3D, 3);
        articleService.sauverArticle(article, panierDAO.savePanier(new Panier(false, 0.0, null, null)));
        assertEquals(cur + 1, countArticles());
    }
}
