package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.paniers.services.dto.Modele3DDTO;
import fr.univlyon1.m2.tiw1.server.ServeurImplTest;
import fr.univlyon1.m2.tiw1.paniers.dao.Modele3DDAO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.Serveur;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ControllerTest {

    private Serveur serveur;
    private Modele3DDAO modele3DDAO;
    private Modele3DService modele3DService;
    private PanierCourantService panierCourantService;

    @BeforeEach
    public void setup() {
        this.serveur = ServeurImplTest.getServeur();
        this.modele3DDAO = (Modele3DDAO) Annuaire.getInstance().lookup("/application/persistence/Modele3DDAO");
        this.modele3DService = (Modele3DService) Annuaire.getInstance().lookup("/application/service/Modele3DService");
        this.panierCourantService = (PanierCourantService) Annuaire.getInstance().lookup("/application/service/PanierCourantService");
    }

    @Test
    void getAllModeles3D() {
        var allModeles = modele3DService.getAllModeles3D();
        assertNotNull(allModeles);
        assertTrue(allModeles.size() > 0);
    }

    @Test
    void createPanierAndGetPanierCourant() {
        serveur.processRequest("panierCourant", "create", new HashMap<>());
        assertNotNull(panierCourantService.getPanierCourant());
    }

    @Test
    void validerPanierCourantAndGetPanier() throws NotFoundException {
        var modele3d = modele3DDAO.getModele3D(17L);
        serveur.processRequest("panierCourant","create", new HashMap<>());
        Map<String, Object> params = new HashMap<>();
        params.put("modele3DDTO", Modele3DDTO.fromModele(modele3d));
        params.put("quantite", 5);
        serveur.processRequest("panierCourant","updatePanierCourant", params);
        Panier panier = panierCourantService.getPanierCourant();
        params = new HashMap<>();
        serveur.processRequest("panierCourant","validatePanier", Map.of("email", ""));
        long id = panier.getNumP(); // FIXME: this is not garanteed to work properly as it relies on the update of the panier object by the DAO
        params.put("id", id);
        assertNotNull(serveur.processRequest("panierArchive","getPanier", params));
    }

    @Test
    void updatePanierCourant() throws NotFoundException {
        var modele3d = modele3DDAO.getModele3D(19L);
        serveur.processRequest("panierCourant","create", new HashMap<>());
        Map<String, Object> params = new HashMap<>();
        params.put("modele3DDTO", Modele3DDTO.fromModele(modele3d));
        params.put("quantite", 3);
        serveur.processRequest("panierCourant","updatePanierCourant", params);
        Panier panier = panierCourantService.getPanierCourant();
        assertEquals(1, panier.getArticles().size());
        var article = panier.getArticles().stream().findFirst().get();
        assertEquals(modele3d, article.getModele3D());
        assertEquals(3, article.getQuantite());
    }
}


