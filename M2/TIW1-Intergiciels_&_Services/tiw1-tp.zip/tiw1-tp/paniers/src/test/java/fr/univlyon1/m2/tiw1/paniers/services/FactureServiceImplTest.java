package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.dao.MaxFacturesException;
import fr.univlyon1.m2.tiw1.paniers.dao.Modele3DDAO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.paniers.model.Article;
import fr.univlyon1.m2.tiw1.paniers.model.Client;
import fr.univlyon1.m2.tiw1.paniers.model.Facture;
import fr.univlyon1.m2.tiw1.paniers.model.Modele3D;
import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.ServeurImplTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FactureServiceImplTest {

    private Modele3DDAO modele3DDAO;
    private FactureService factureService;
    private static Facture facture;

    @BeforeEach
    void setUp() {
        ServeurImplTest.getServeur();
        this.modele3DDAO = (Modele3DDAO) Annuaire.getInstance().lookup("/application/persistence/Modele3DDAO");
        this.factureService = (FactureService) Annuaire.getInstance().lookup("/application/service/FactureService");
    }

    @Test
    @Order(1)
    void createFacture() throws NotFoundException, MaxFacturesException {
        Client client = new Client("Finalgo");
        Modele3D modele3D = modele3DDAO.getModele3D(1L);
        Article article = new Article(null, modele3D, 42);
        Panier panier = new Panier(false, 0.0, null, null);
        panier.setArticles(List.of(article));
        facture = factureService.createFacture(client, panier);
        assertEquals(facture.getId(), 1L);
    }

    @Test
    @Order(2)
    void getFacture() throws NotFoundException, MaxFacturesException {
        Facture daoFacture = factureService.getFacture(1L);
        assertEquals(daoFacture, facture);
    }

    @Test
    @Order(2)
    void printFacture() {
        String html = facture.print();
        String htmlLetters = html.replaceAll("[^a-zA-Z0-9]", "");
        String expectedHtmlLetters = "DOCTYPEHTMLhtmllangfrheadmetacharsetUTF8titleFacturen1titleheadbodyh1Facturen1h1h2destinationdeFinalgoh2h2Pourlepanier1h2h3Dtaildesarticlesdupanierh3tabletrthModleththQuantitthtrtrtdModele1tdtd42tdtrtablebodyhtml";
        assertEquals(htmlLetters, expectedHtmlLetters);
    }


    @Test
    @Order(2)
    void releaseAndMaxFactures() throws NotFoundException {
        Long lastFactureId = null;
        for (Integer i = 0; i < 13; i++) {
            Client client = new Client("Client " + i);
            Modele3D modele3D = modele3DDAO.getModele3D(i);
            Article article = new Article(null, modele3D, 42);
            Panier panier = new Panier(false, 0.0, null, null);
            panier.setArticles(List.of(article));
            try {
                facture = factureService.createFacture(client, panier);
                lastFactureId = facture.getId();
            } catch (MaxFacturesException e) {
                assertEquals(i, 11);
                factureService.releaseFacture(lastFactureId);
            }
        }
    }
}
