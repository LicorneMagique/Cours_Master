package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.ServeurImplTest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class Modele3DServiceImplTest {

    private Modele3DService modele3DService;

    @BeforeEach
    void setUp() {
        ServeurImplTest.getServeur();
        this.modele3DService = (Modele3DService) Annuaire.getInstance().lookup("/application/service/Modele3DService");
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getAllModeles3D() {
        assertNotNull(modele3DService.getAllModeles3D());
    }

    @Test
    void getModele3D() throws NotFoundException {
        Assertions.assertEquals(5L, modele3DService.getModele3D(5L).getId());
    }
}
