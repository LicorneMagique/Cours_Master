package fr.univlyon1.m2.tiw1.paniers.services;

import fr.univlyon1.m2.tiw1.paniers.model.Panier;
import fr.univlyon1.m2.tiw1.paniers.dao.Modele3DDAO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PanierCourantServiceImplTest {

    private PanierCourantService panierCourantService;
    private Modele3DDAO modele3DDAO;
    private DBAccess dBAccess;

    @BeforeEach
    public void setup() {
        this.panierCourantService = (PanierCourantService) Annuaire.getInstance().lookup("/application/service/PanierCourantService");
        this.modele3DDAO = (Modele3DDAO) Annuaire.getInstance().lookup("/application/persistence/Modele3DDAO");
        this.dBAccess = (DBAccess) Annuaire.getInstance().lookup("/application/persistence/DBAccess");
    }

    private int countPaniers() throws SQLException {
        var rs = dBAccess.getConnection().createStatement().executeQuery(
                "SELECT COUNT(*) FROM panier");
        rs.next();
        return rs.getInt(1);
    }

    @Test
    void creerPanierCourant() {
        Panier panier = panierCourantService.getPanierCourant();
        Panier panier2 = panierCourantService.creerPanierCourant();
        assert(panier != panier2);
        assertNotNull(panier2);
        assertFalse(panier2.isFerme());
    }

    @Test
    void ajouterModeles3D() throws NotFoundException {
        Panier panier = panierCourantService.creerPanierCourant();
        assertEquals(0, panier.getArticles().size());
        panierCourantService.ajouterModeles3D(modele3DDAO.getModele3D(7L), 3);
        assertEquals(1, panier.getArticles().size());
        assertEquals(3, panier.getArticles().stream().findFirst().get().getQuantite());
    }

    @Test
    void supprimerModeles3D() throws NotFoundException, InvalidArticleException {
        var modele3d = modele3DDAO.getModele3D(9L);
        Panier panier = panierCourantService.creerPanierCourant();
        panierCourantService.ajouterModeles3D(modele3d, 7);
        assertEquals(7, panier.getArticles().stream().findFirst().get().getQuantite());
        panierCourantService.supprimerModeles3D(modele3d, 3);
        assertEquals(4, panier.getArticles().stream().findFirst().get().getQuantite());
        assertThrows(InvalidArticleException.class, () -> panierCourantService.supprimerModeles3D(modele3d, 6));
    }

    @Test
    void getAllArticles() throws NotFoundException {
        panierCourantService.creerPanierCourant();
        var articles = panierCourantService.getAllArticles();
        assertEquals(0, articles.size());
        panierCourantService.ajouterModeles3D(modele3DDAO.getModele3D(11L), 9);
        assertEquals(1, panierCourantService.getAllArticles().size());
    }

    @Test
    void validerPanierCourant() throws EmptyPanierException, SQLException, NotFoundException {
        var panier = panierCourantService.creerPanierCourant();
        int cur = countPaniers();
        Assertions.assertFalse(panier.isFerme());
        assertThrows(EmptyPanierException.class, () -> panierCourantService.validerPanierCourant(""));
        panierCourantService.ajouterModeles3D(modele3DDAO.getModele3D(13L), 5);
        panierCourantService.validerPanierCourant("");
        Assertions.assertTrue(panier.isFerme());
        Assertions.assertNotEquals(panier, panierCourantService.getPanierCourant());
        assertEquals(cur + 1, countPaniers());
    }

    @Test
    void getPanierCourant() {
        Panier panier = panierCourantService.creerPanierCourant();
        Assertions.assertEquals(panier, panierCourantService.getPanierCourant());
        assertNotNull(panierCourantService.getPanierCourant());
    }
}
