package fr.univlyon1.m2.tiw1.server;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AnnuaireTest {

    private static Annuaire annuaire;

    @BeforeAll
    static void setUp() {
        annuaire = Annuaire.getInstance();
    }

    @Test
    @Order(1)
    void bindTest() {
        annuaire.bind("key", "value");
        assertEquals(annuaire.lookup("key"), "value");
    }

    @Test
    @Order(2)
    void rebindTest() {
        annuaire.bind("key", "value");
        assertEquals(annuaire.lookup("key"), "value");
        annuaire.rebind("key", "otherValue");
        assertEquals(annuaire.lookup("key"), "otherValue");
    }

    @Test
    @Order(3)
    void unbindTest() {
        annuaire.bind("key", "value");
        assertEquals(annuaire.lookup("key"), "value");
        annuaire.unbind("key");
        assertNull(annuaire.lookup("key"));
    }

    @Test
    @Order(4)
    void lookupTest() {
        annuaire.bind("key", "value");
        assertEquals(annuaire.lookup("key"), "value");
    }

}
