package fr.univlyon1.m2.tiw1.server;

import fr.univlyon1.m2.tiw1.paniers.services.Modele3DService;
import fr.univlyon1.m2.tiw1.paniers.services.dto.Modele3DDTO;
import fr.univlyon1.m2.tiw1.paniers.dao.NotFoundException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ServeurImplTest {

    private static Long panierId;
    private static Serveur serveur;
    private static Modele3DService modele3DService;
    private static Long modele3DId;

    @BeforeAll
    static void setUp() {
        panierId = null;
        getServeur().processRequest("panierCourant", "create", new HashMap<>());
        modele3DService = (Modele3DService) Annuaire.getInstance().lookup("/application/service/Modele3DService");
        modele3DId = 1L;
    }

    public static Serveur getServeur() {
        if (serveur == null) {
            serveur = new ServeurImpl();
        }
        return serveur;
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    @Order(1)
    void addModelTest() {
        Modele3DDTO modele3DDTO = null;
        try {
            modele3DDTO = Modele3DDTO.fromModele(modele3DService.getModele3D(modele3DId));
        } catch (NotFoundException e) {
            fail();
        }
        Map<String, Object> params = new HashMap<>();
        params.put("modele3DDTO", modele3DDTO);
        JSONObject response = new JSONObject(getServeur().processRequest("panierCourant", "addModel3D", params));
        assertEquals(response.getNumber("status"), 204);
    }

    @Test
    @Order(2)
    void deleteModelTest() {
        Modele3DDTO modele3DDTO = null;
        try {
            modele3DDTO = Modele3DDTO.fromModele(modele3DService.getModele3D(modele3DId));
        } catch (NotFoundException e) {
            fail();
        }
        Map<String, Object> params = new HashMap<>();
        params.put("modele3DDTO", modele3DDTO);
        JSONObject response = new JSONObject(getServeur().processRequest("panierCourant", "deleteModel3D", params));
        assertEquals(response.getNumber("status"), 204);
        // Rajout du modele pour validation du panier
        getServeur().processRequest("panierCourant", "addModel3D", params);
    }

    @Test
    @Order(3)
    void validatePanierTest() {
        JSONObject response = new JSONObject(getServeur().processRequest("panierCourant", "validatePanier", Map.of("email", "")));
        JSONObject body = new JSONObject(response.get("content").toString());
        panierId = body.getLong("numP");
        assertNotNull(panierId);
        assertEquals(response.getNumber("status"), 200);
    }

    @Test
    @Order(4)
    void getPanierFermeTest() {
        Map<String, Object> params = Map.of(
                "id", panierId,
                "email", ""
        );
        JSONObject response = new JSONObject(getServeur().processRequest("panierArchive", "getPanier", params));
        assertEquals(response.getNumber("status"), 200);
        JSONObject panier = new JSONObject(response.getString("content"));
        assertEquals(panierId, panier.getLong("numP"));
        assertTrue(panier.getBoolean("ferme"));
        JSONArray articles = panier.getJSONArray("articles");
        assertEquals(articles.getJSONObject(0).getLong("modele3DId"), modele3DId);
    }

}
