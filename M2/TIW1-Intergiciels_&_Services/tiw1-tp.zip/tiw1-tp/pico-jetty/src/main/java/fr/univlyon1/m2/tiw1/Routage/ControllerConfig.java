package fr.univlyon1.m2.tiw1.Routage;

import java.util.ArrayList;
import java.util.List;

public class ControllerConfig {
    private String classPath;
    private String baseUrl;
    private List<Route> routes;

    public ControllerConfig() {
        this.classPath = null;
        this.baseUrl = null;
        this.routes = new ArrayList<>();
    }

    public ControllerConfig(String classPath, String baseUrl, List<Route> routes) {
        this.classPath = classPath;
        this.baseUrl = baseUrl;
        this.routes = routes;
    }

    public String getClassPath() {
        return classPath;
    }

    public void setClassPath(String classPath) {
        this.classPath = classPath;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public List<Route> getRoutes() {
        return routes;
    }

    public void setRoutes(List<Route> routes) {
        this.routes = routes;
    }
}
