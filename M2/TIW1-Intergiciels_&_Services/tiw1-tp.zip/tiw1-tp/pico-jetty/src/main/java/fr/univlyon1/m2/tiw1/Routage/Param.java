package fr.univlyon1.m2.tiw1.Routage;

public class Param {
    private String type;
    private String key;

    public Param() {
        this.type = null;
        this.key = null;
    }

    public Param(String type, String method) {
        this.type = type;
        this.key = method;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

}
