package fr.univlyon1.m2.tiw1.Routage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Route {
    private String url;
    private String method;
    private String command;
    private List<Param> params;

    public Route() {
        this.url = null;
        this.method = null;
        this.command = null;
        this.params = new ArrayList<>();
    }

    public Route(String url, String method, String command, List<Param> params) {
        this.url = url;
        this.method = method;
        this.command = command;
        this.params = params;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public List<Param> getParams() {
        return params;
    }

    public void setParams(List<Param> params) {
        this.params = params;
    }
}
