package fr.univlyon1.m2.tiw1.servers;

import fr.univlyon1.m2.tiw1.servlet.MainController_Component;
import org.eclipse.jetty.servlet.ServletHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JettyLauncher {
    private static final Logger logger = LoggerFactory.getLogger(JettyLauncher.class);

    public static void run() {
        ServletHandler servletHandler = new ServletHandler();
        servletHandler.addServletWithMapping(MainController_Component.class, "/");

        try {
            logger.info("Main controller: " + servletHandler.getServletMapping("/"));
            JettyServer.start(servletHandler);
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage());
        }
    }
}
