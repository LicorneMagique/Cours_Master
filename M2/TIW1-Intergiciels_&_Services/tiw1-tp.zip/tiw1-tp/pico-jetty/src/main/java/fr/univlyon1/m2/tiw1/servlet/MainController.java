package fr.univlyon1.m2.tiw1.servlet;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.univlyon1.m2.tiw1.Routage.ControllerConfig;
import fr.univlyon1.m2.tiw1.Routage.Param;
import fr.univlyon1.m2.tiw1.Routage.Route;
import fr.univlyon1.m2.tiw1.annotations.Component;
import fr.univlyon1.m2.tiw1.server.Controller;
import fr.univlyon1.m2.tiw1.server.Response;
import fr.univlyon1.m2.tiw1.server.ContextService;
import fr.univlyon1.m2.tiw1.server.Pico;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.picocontainer.MutablePicoContainer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.*;

@Component
@WebServlet(name = "mainController", urlPatterns = "/*")
public class MainController extends HttpServlet {
    private MutablePicoContainer picoContainer;
    private List<ControllerConfig> controllersConfig;
    private PrintWriter out;

    @Override
    public void init() throws ServletException {
        super.init();
        this.picoContainer = Pico.getPicoContainer();
        this.controllersConfig = getControllersConfig();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        this.out = resp.getWriter();
        Response<String> response = handleRequest(req);
        out.write(response.getContent());
        out.flush();
        resp.setStatus(response.getStatus());
    }

    /**
     * Parcours des routes auxquelles le controleur peut répondre
     * On cherche une route pour répondre exactement à l'url et à la méthode
     * Si des paramètres sont attendus
     * Récupérer les paramètres de la requête dans le payload
     * Parcours des paramètres attendu pour la route
     *
     * @param req
     * @param route
     * @return
     * @throws IOException, ClassNotFoundException
     */
    private Map<String, Object> getParamsFromPayloadByRoute(HttpServletRequest req, Route route) throws IOException, ClassNotFoundException, JSONException {
        Map<String, Object> params = new HashMap<>();

        JSONObject requestParams = getParamsFromRequest(req);

        for (Param requiredParam : route.getParams()) {
            if (!requestParams.has(requiredParam.getKey())) {
                throw new JSONException(requiredParam.getKey() + " ne doit pas etre vide.");
            }
            Class<?> paramType;
            paramType = Class.forName(requiredParam.getType());
            ObjectMapper objectMapper = new ObjectMapper();
            Object o = requestParams.get(requiredParam.getKey()).toString();
            try {
                o = objectMapper.readValue(o.toString(), paramType);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            params.put(requiredParam.getKey(), o);
        }

        return params;
    }

    private Response<String> handleRequest(HttpServletRequest req) {
        // Récupération de l'url à partir du premier slash
        List<String> path = Arrays.asList(req.getRequestURI().split("/"));
        // Page d'accueil si url du type host ou host/
        if (path.size() == 0 || path.subList(1, path.size()).size() == 0) {
            return new Response<>("Page d'accueil", 200);
        }

        // Récupération de l'url sans le host
        path = path.subList(1, path.size());

        // Récupération de la configuration du controleur à partir de la ressource demandée dans l'url /panierCourant utilisera la config du controleur PanierCourantRessource par exemple
        ControllerConfig controllerConfig = getControllerConfigByPathBase(path.get(0));
        if (controllerConfig == null) {
            return new Response<>("Ressource non prise en charge", 404);
        }

        Route route = getRouteByControllerConfigAndUrlAndMethod(controllerConfig, String.join("/", path), req.getMethod());
        if (route == null) {
            return new Response<>("Methode ou URL non prise en charge", 405);
        }

        Map<String, Object> paramsToSend = new HashMap<>();
        if (route.getParams().size() > 0) {
            try {
                paramsToSend = getParamsFromPayloadByRoute(req, route);
            } catch (JSONException e) {
                return new Response<>(e.getMessage(), 400);
            } catch (Exception e) {
                return new Response<>(e.getMessage(), 500);
            }
        }
        String commandeToSend = route.getCommand();
        ContextService contextService = picoContainer.getComponent(ContextService.class);
        Controller controller = (Controller) contextService.getComponent(controllerConfig.getClassPath());
        return controller.process(commandeToSend, paramsToSend);
    }

    private Route getRouteByControllerConfigAndUrlAndMethod(ControllerConfig controllerConfig, String path, String method) {
        for (Route route : controllerConfig.getRoutes()) {
            // Recherche de la route exact avec la bonne méthode http
            if (route.getUrl().equals(path) && route.getMethod().equals(method)) {
                return route;
            }
        }
        return null;
    }

    private ControllerConfig getControllerConfigByPathBase(String pathBase) {
        for (ControllerConfig controllerConfig : controllersConfig) {
            if (controllerConfig.getBaseUrl().equals(pathBase)) {
                return controllerConfig;
            }
        }
        return null;
    }

    private List<ControllerConfig> getControllersConfig() {
        JSONArray controllersConfigObject = new JSONObject(getConfigStr()).getJSONArray("controllers");
        List<ControllerConfig> controllersConfig = new ArrayList<>();
        for (int i = 0; i < controllersConfigObject.length(); i++) {
            JSONObject controllerConfigObject = controllersConfigObject.getJSONObject(i);
            ControllerConfig controllerConfig = new ControllerConfig();
            controllerConfig.setClassPath(controllerConfigObject.getString("classPath"));
            controllerConfig.setBaseUrl(controllerConfigObject.getString("baseUrl"));
            List<Route> routesConfig = new ArrayList<>();
            JSONArray routesConfigObject = controllerConfigObject.getJSONArray("routes");
            for (int j = 0; j < routesConfigObject.length(); j++) {
                JSONObject routeConfigObject = routesConfigObject.getJSONObject(j);
                Route routeConfig = new Route();
                routeConfig.setUrl(routeConfigObject.getString("url"));
                routeConfig.setMethod(routeConfigObject.getString("method"));
                routeConfig.setCommand(routeConfigObject.getString("command"));
                List<Param> paramsConfig = new ArrayList<>();
                JSONArray paramsConfigObject = routeConfigObject.getJSONArray("params");
                for (int k = 0; k < paramsConfigObject.length(); k++) {
                    JSONObject paramConfigObject = paramsConfigObject.getJSONObject(k);
                    Param paramConfig = new Param(paramConfigObject.getString("type"), paramConfigObject.getString("key"));
                    paramsConfig.add(paramConfig);
                }
                routeConfig.setParams(paramsConfig);
                routesConfig.add(routeConfig);
            }
            controllerConfig.setRoutes(routesConfig);
            controllersConfig.add(controllerConfig);
        }
        return controllersConfig;
    }

    private String getConfigStr() {
        ClassLoader cl = getClass().getClassLoader();
        InputStream configStream = cl.getResourceAsStream("config.json");
        String configStr = null;
        try {
            configStr = new String(configStream.readAllBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return configStr;
    }

    private String getBody(HttpServletRequest req) throws IOException {
        String body = "";
        BufferedReader reader = req.getReader();
        String line = reader.readLine();
        while (line != null) {
            body += line;
            line = reader.readLine();
        }
        return body;
    }

    private JSONObject getParamsFromRequest(HttpServletRequest req) throws IOException {
        JSONObject params;
        if (req.getMethod().equals("GET")) {
            params = new JSONObject();
            req.getParameterMap().entrySet().forEach(entry -> params.put(entry.getKey(), entry.getValue()[0]));
        } else {
            String body = getBody(req);
            params = new JSONObject(body);
        }
        return params;
    }

}


