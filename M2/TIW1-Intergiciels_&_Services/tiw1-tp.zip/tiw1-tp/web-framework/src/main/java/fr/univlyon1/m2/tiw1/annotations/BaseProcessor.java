package fr.univlyon1.m2.tiw1.annotations;

import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeSpec;
import fr.univlyon1.m2.tiw1.server.Annuaire;
import fr.univlyon1.m2.tiw1.server.Observable;
import fr.univlyon1.m2.tiw1.server.Response;
import org.codehaus.plexus.util.FileUtils;
import org.json.JSONObject;
import org.picocontainer.Startable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Types;
import javax.tools.JavaFileObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@SupportedAnnotationTypes({
        "fr.univlyon1.m2.tiw1.annotations.Component",
        "fr.univlyon1.m2.tiw1.annotations.Controller",
        "fr.univlyon1.m2.tiw1.annotations.Service",
        "fr.univlyon1.m2.tiw1.annotations.Persistence",
        "fr.univlyon1.m2.tiw1.annotations.Server"
})
public class BaseProcessor extends AbstractProcessor {
    private static final Logger logger = LoggerFactory.getLogger(BaseProcessor.class);
    FieldSpec loggerField, annuaireField;
    MethodSpec validateParametersMethod;
    private Types typeUtils;
    private static Map<String, Element> firstAnnotedElements = null;
    private static String applicationName;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        this.typeUtils = processingEnv.getTypeUtils();

        this.loggerField = FieldSpec
                .builder(Logger.class, "logger")
                .addModifiers(Modifier.PRIVATE, Modifier.FINAL)
                .initializer("org.slf4j.LoggerFactory.getLogger(this.getClass())")
                .build();

        this.annuaireField = FieldSpec
                .builder(Annuaire.class, "annuaire")
                .addModifiers(Modifier.PRIVATE)
                .build();

        this.validateParametersMethod = MethodSpec
                .methodBuilder("validateParameters")
                .addModifiers(Modifier.PRIVATE)
                .returns(boolean.class)
                .addParameter(ParameterizedTypeName.get(List.class, String.class), "keys")
                .addParameter(ParameterizedTypeName.get(Map.class, String.class, Object.class), "parametres")
                .addCode("for (String key : keys) {\n" +
                        "    if (!parametres.containsKey(key)) {\n" +
                        "        return false;\n" +
                        "    }\n" +
                        "}\n" +
                        "return true;")
                .build();
    }

    private MethodSpec getBusinessStartMethod(Element element) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("start")
                .addModifiers(Modifier.PUBLIC)
                .addCode("this.annuaire = Annuaire.getInstance();")
                .addCode("\nlogger.info(\"Composant \" + this.toString() + \" démarré.\");");
        addCodeIfMethodExist(element, builder, "start", "\nsuper.start();");
        return builder.build();
    }

    private MethodSpec getControllerStartMethod(Element element) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("start")
                .addModifiers(Modifier.PUBLIC)
                .addCode("this.annuaire = Annuaire.getInstance();")
                .addCode("\nlogger.info(\"Nom de l'organisation : \" + annuaire.lookup(\"/nomOrganisation\"));");
        addCodeIfMethodExist(element, builder, "start", "\nsuper.start();");
        return builder.build();
    }

    private MethodSpec getBusinessStopMethod(Element element) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("stop")
                .addModifiers(Modifier.PUBLIC)
                .addCode("logger.info(\"Composant \" + this.toString() + \" arrêté.\");");
        addCodeIfMethodExist(element, builder, "stop", "\nsuper.stop();");
        return builder.build();
    }

    private MethodSpec getServiceStartMethod(Element element, Map<String, ?> classesToInit) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("start")
                .addModifiers(Modifier.PUBLIC)
                .addCode("this.annuaire = Annuaire.getInstance();");
        classesToInit.keySet().forEach(key -> {
            builder.addCode(String.format(
                    "\nthis.%s = annuaire.getPathFromClassName(\"%s\");",
                    "path" + key, key
            ));
        });
        builder.addCode("\nupdate();");
        classesToInit.keySet().forEach(key -> {
            builder.addCode(String.format(
                    "\nannuaire.subscribe(this, %s);",
                    "path" + key
            ));
        });
        addCodeIfMethodExist(element, builder, "start", "\nsuper.start();");
        return builder.build();
    }

    private MethodSpec getPersistenceStartMethod(Element element) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("start")
                .addModifiers(Modifier.PUBLIC);
        String[] params = element.getAnnotation(Persistence.class).params();
        for (Integer i = 0; i < params.length -1; i += 2) {
            String value = params[i + 1];
            value = value.matches("[0-9]+") ? value : "\"" + value + "\"";
            builder.addCode(String.format(
                    "this.%s = %s;\n", params[i], value
            ));
        }
        addCodeIfMethodExist(element, builder, "start", "super.start();\n");
        return builder.build();
    }

    private MethodSpec getServiceStopMethod(Map<String, ?> classesToInit) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("stop")
                .addModifiers(Modifier.PUBLIC);
        classesToInit.keySet().forEach(key -> {
            builder.addCode(String.format(
                    "annuaire.unsubscribe(this, %s);\n",
                    "path" + key
            ));
        });
        return builder.build();
    }

    private MethodSpec getServiceUpdateMethod(Map<String, TypeMirror> classesToInit) {
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("update")
                .addModifiers(Modifier.PUBLIC);
        classesToInit.keySet().forEach(key -> {
            builder.addCode(String.format(
                    "this.%s = (%s) annuaire.lookup(%s);\n",
                    getAttributeNameFromClass(key), classesToInit.get(key).toString(), "path" + key
            ));
        });
        return builder.build();
    }

    private MethodSpec getProcessMethod(Element element) {
        String responseType = Response.class.getName();
        MethodSpec.Builder builder = MethodSpec
                .methodBuilder("process")
                .addModifiers(Modifier.PUBLIC)
                .returns(ParameterizedTypeName.get(Response.class, String.class))
                .addParameter(String.class, "method")
                .addParameter(ParameterizedTypeName.get(Map.class, String.class, Object.class), "parameters")
                .addCode(String.format(
                        "%s<String> defaultResponse = new %s<>(400);\n" +
                        "switch (method) {\n",
                        responseType, responseType));
        element.getEnclosedElements().stream()
                .filter(elem -> elem.getKind().compareTo(ElementKind.METHOD) == 0)
                .filter(method -> method.getAnnotation(RequestMapping.class) != null)
                .forEach(method -> {
                    List<String> parametersName = ((ExecutableElement) method).getParameters().stream()
                            .map(p -> String.format("\"%s\"", p))
                            .collect(Collectors.toList());
                    List<String> parametersCall = ((ExecutableElement) method).getParameters().stream()
                            .map(p -> String.format("(%s) parameters.get(\"%s\")", p.asType(), p))
                            .collect(Collectors.toList());
                    builder.addCode(String.format(
                            "    case \"%s\":\n" +
                            "        return validateParameters(java.util.List.of(%s), parameters) ?\n" +
                            "            %s(%s) : defaultResponse;\n",
                            method.getSimpleName(),
                            String.join(", ", parametersName),
                            method.getSimpleName(), String.join(", ", parametersCall)
                    ));
                });
        builder.addCode(String.format(
                "    default:\n" +
                "        return new %s<>(404);\n" +
                "}\n",
                responseType));
        return builder.build();
    }

    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        if (firstAnnotedElements == null) {
            firstAnnotedElements = new HashMap<>();
            for (TypeElement annotation : annotations) {
                for (Element element : roundEnv.getElementsAnnotatedWith(annotation)) {
                    if (annotation.toString().equals(Server.class.getName())) {
                        applicationName = element.getAnnotation(Server.class).applicationName();
                    } else {
                        firstAnnotedElements.put(element.toString(), element);
                    }
                }
            }
        }

        for (TypeElement annotation : annotations) {
            logger.info("Annotation : " + annotation.getSimpleName());
            for (Element element : roundEnv.getElementsAnnotatedWith(annotation)) {
                logger.info("Element annote : " + element.toString());
                COMPONENT_TYPE type = getComponentTypeFromElement(element);
                if (type == null) {
                    continue;
                }
                switch (type) {
                    case BUSINESS:
                        processBusiness(element);
                        break;
                    case CONTROLLER:
                        processController(element);
                        break;
                    case SERVICE:
                        processService(element);
                        break;
                    case PERSISTENCE:
                        processPersistence(element);
                        break;
                    default:
                        break;
                }
            }
        }
        try {
            if (applicationName != null) {
                createConfigFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    private void createConfigFile() throws IOException {
        JSONObject config = new JSONObject();

        JSONObject applicationConfig = new JSONObject();
        applicationConfig.put("name", applicationName);
        Map<COMPONENT_TYPE, List<JSONObject>> components = new HashMap<>();
        firstAnnotedElements.values().forEach(classe -> {
            JSONObject component = new JSONObject();
            Element bestClassForName = getBestElementForName(classe);
            COMPONENT_TYPE type = getComponentTypeFromElement(classe);
            component.put("path", getClassPath(type, bestClassForName.toString()));
            component.put("class-name", classe);
            components.putIfAbsent(type, new ArrayList<>());
            components.get(type).add(component);
        });
        applicationConfig.put("business-components", components.get(COMPONENT_TYPE.CONTROLLER));
        applicationConfig.put("service-components", components.get(COMPONENT_TYPE.SERVICE));
        applicationConfig.put("persistence-components", components.get(COMPONENT_TYPE.PERSISTENCE));
        config.put("application-config", applicationConfig);

        List<JSONObject> controllers = new ArrayList<>();
        firstAnnotedElements.values().stream()
                .filter(classe -> getComponentTypeFromElement(classe).equals(COMPONENT_TYPE.CONTROLLER))
                .forEach(classe -> {
                    Controller classeAnnotation = classe.getAnnotation(Controller.class);
                    JSONObject controller = new JSONObject();
                    Element bestClassForName = getBestElementForName(classe);
                    controller.put("classPath", getClassPath(COMPONENT_TYPE.CONTROLLER, bestClassForName.toString()));
                    controller.put("baseUrl", classe.getAnnotation(Controller.class).baseUrl());
                    List<JSONObject> routes = new ArrayList<>();
                    classe.getEnclosedElements().stream()
                            .filter(elem -> elem.getKind().compareTo(ElementKind.METHOD) == 0)
                            .filter(method -> method.getAnnotation(RequestMapping.class) != null)
                            .forEach(method -> {
                                RequestMapping mapping = method.getAnnotation(RequestMapping.class);
                                JSONObject route = new JSONObject();
                                route.put("url", classeAnnotation.baseUrl() + mapping.url());
                                route.put("method", mapping.method());
                                route.put("command", method.getSimpleName());
                                List<JSONObject> params = new ArrayList<>();
                                ((ExecutableElement) method).getParameters().forEach(p -> {
                                    JSONObject param = new JSONObject();
                                    param.put("type", p.asType());
                                    param.put("key", p);
                                    params.add(param);
                                });
                                route.put("params", params);
                                routes.add(route);
                            });
                    controller.put("routes", routes);
            controllers.add(controller);
        });
        config.put("controllers", controllers);

        FileUtils.fileWrite("target/classes/config.json", config.toString());
    }

    private String getClassPath(COMPONENT_TYPE type, String path) {
        var splitPath = path.split("[.]");
        String endPath = splitPath[splitPath.length - 1];
        switch (type) {
            case CONTROLLER:
                return "/application/" + endPath;
            case SERVICE:
                return "/application/service/" + endPath;
            case PERSISTENCE:
                return "/application/persistence/" + endPath;
            default:
                logger.error("On ne devrait pas arriver là.");
                return null;
        }
    }
    private COMPONENT_TYPE getComponentTypeFromElement(Element element) {
        Component component = element.getAnnotation(Component.class);
        Controller controller = element.getAnnotation(Controller.class);
        Service service = element.getAnnotation(Service.class);
        Persistence persistence = element.getAnnotation(Persistence.class);
        if (component != null) {
            return component.type();
        } else if (controller != null) {
            return controller.type();
        } else if (service != null) {
            return service.type();
        } else if (persistence != null) {
            return persistence.type();
        }
        return null;
    }

    private void processBusiness(Element element) {
        MethodSpec startMethod = getBusinessStartMethod(element);
        MethodSpec stopMethod = getBusinessStopMethod(element);
        TypeSpec subComponent = getClassBuilderHead(element, "_Component")
                .addFields(List.of(this.loggerField, this.annuaireField))
                .addMethods(List.of(startMethod, stopMethod))
                .build();
        saveSubClass(element, subComponent);
    }

    private TypeSpec.Builder getClassBuilderHead(Element element, String suffix) {
        Modifier abstractModifier = element.getModifiers().contains(Modifier.ABSTRACT) ?
                Modifier.ABSTRACT : element.getModifiers().stream().findAny().get();
        ClassName newClassName = ClassName.bestGuess(element + suffix);
        return TypeSpec
                .classBuilder(newClassName)
                .addModifiers(Modifier.PUBLIC, abstractModifier)
                .superclass(element.asType());
    }

    private Element getBestElementForName(Element element) {
        List<TypeMirror> interfaces = (List<TypeMirror>) ((TypeElement) element).getInterfaces();
        String bestName = "";
        Element bestElement = null;
        for (TypeMirror i : interfaces) {
            if (element.toString().contains(i.toString()) && i.toString().length() > bestName.length()) {
                bestName = i.toString();
                bestElement = typeUtils.asElement(i);
            }
        }
        if (bestName.isEmpty() || interfaces.isEmpty()) {
            bestName = element.toString();
            bestElement = element;
        }
        return bestElement;
    }

    private void processController(Element element) {
        MethodSpec startMethod = getControllerStartMethod(element);
        MethodSpec processMethod = getProcessMethod(element);
        TypeSpec subComponent = getClassBuilderHead(element, "_Controller")
                .addAnnotation(Service.class)
                .addSuperinterface(fr.univlyon1.m2.tiw1.server.Controller.class)
                .addFields(List.of(this.loggerField, this.annuaireField))
                .addMethods(List.of(startMethod, this.validateParametersMethod, processMethod))
                .build();
        saveSubClass(element, subComponent);
    }

    private void processService(Element element) {
        Map<String, TypeMirror> classesToInit = getClassesToInit(element);
        Iterable<FieldSpec> serviceFieldsToAdd = getServiceFieldsToAdd(classesToInit);
        MethodSpec startMethod = getServiceStartMethod(element, classesToInit);
        MethodSpec stopMethod = getServiceStopMethod(classesToInit);
        MethodSpec updateMethod = getServiceUpdateMethod(classesToInit);
        TypeSpec subComponent = getClassBuilderHead(element, "_Service")
                .addSuperinterface(Observable.class)
                .addSuperinterface(Startable.class)
                .addAnnotation(Component.class)
                .addFields(List.of(this.loggerField, this.annuaireField))
                .addFields(serviceFieldsToAdd)
                .addMethods(List.of(startMethod, stopMethod, updateMethod))
                .build();
        saveSubClass(element, subComponent);
    }

    private void processPersistence(Element element) {
        Iterable<MethodSpec> start = List.of(getPersistenceStartMethod(element));
        TypeSpec subComponent = getClassBuilderHead(element, "_Persistence")
                .addAnnotation(Service.class)
                .addField(this.loggerField)
                .addMethods(start)
                .build();
        saveSubClass(element, subComponent);
    }

    public void saveSubClass(Element element, TypeSpec subComponent) {
        String packageName = element.toString();
        int separator = packageName.lastIndexOf(".");
        packageName = packageName.substring(0, separator);
        // Création du fichier source Java
        JavaFile javaFile = JavaFile
                .builder(packageName, subComponent)
                .build();
        try {
            // Utilisation de l'interface Filer pour récupérer un PrintWriter
            // vers le répertoire GeneratedSources indiqué dans le pom
            JavaFileObject builderFile = processingEnv
                    .getFiler()
                    .createSourceFile(subComponent.name);
            try (PrintWriter out = new PrintWriter(builderFile.openWriter())) {
                // Ecriture du fichier
                javaFile.writeTo(out);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Iterable<FieldSpec> getServiceFieldsToAdd(Map<String, ?> classesToInit) {
        List<FieldSpec> fields = new ArrayList<>();
        classesToInit.keySet().forEach(key -> {
            fields.add(
                    FieldSpec
                        .builder(String.class, "path" + key)
                        .addModifiers(Modifier.PRIVATE)
                        .build()
            );
        });
        return fields;
    }

    private Map<String, TypeMirror> getClassesToInit(Element element) {
        Map<String, TypeMirror> classes = new HashMap<>();
        List<Element> elementsToUse = new ArrayList<>();
        Element currentElement = element;
        while (!currentElement.getSimpleName().toString().equals("Object")) {
            elementsToUse.add(currentElement);
            currentElement = getParentIfExist(currentElement);
        }
        Set<String> authorizedNames = firstAnnotedElements.values().stream()
                .map(e -> getBestElementForName(e).toString())
                .collect(Collectors.toSet());
        elementsToUse.forEach(elementToUse -> {
            elementToUse.getEnclosedElements().forEach(symbol -> {
                if (symbol.getKind().isField()) {
                    String classToInit = getAttributeClassFromName(symbol.getSimpleName().toString());
                    if (authorizedNames.contains(symbol.asType().toString())) {
                        classes.put(classToInit, symbol.asType());
                    }
                }
            });
        });
        return classes;
    }

    private Element getParentIfExist(Element element) {
        TypeMirror parent = ((TypeElement) element).getSuperclass();
        return typeUtils.asElement(parent);
    }

    private String getAttributeNameFromClass(String name) {
        return name.substring(0, 1).toLowerCase() + name.substring(1);
    }

    private String getAttributeClassFromName(String name) {
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    private void addCodeIfMethodExist(Element parent, MethodSpec.Builder builder, String methdoName, String code) {
        parent.getEnclosedElements().forEach(symbol -> {
            if (symbol.getKind().compareTo(ElementKind.METHOD) == 0 && symbol.getSimpleName().toString().equals(methdoName)) {
                builder.addCode(code);
            }
        });
    }
}
