package fr.univlyon1.m2.tiw1.annotations;

public enum Method {
    GET,
    POST,
    PUT,
    DELETE
}
