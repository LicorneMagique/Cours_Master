package fr.univlyon1.m2.tiw1.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Annuaire {

    private static Annuaire instance;
    private final Map<String, Object> annuaire;
    private final Map<String, List<Observable>> observeurs;

    private Annuaire() {
        annuaire = (Map<String, Object>) Pico.getPicoContainer().getComponent("annuaire");
        observeurs = new HashMap<>();
    }

    public static Annuaire getInstance() {
        if (instance == null) {
            instance = new Annuaire();
        }
        return instance;
    }

    public void bind(String path, Object object) {
        annuaire.put(path, object);
    }

    public void rebind(String path, Object object) {
        annuaire.put(path, object);
        if (!observeurs.containsKey(path)) {
            return;
        }
        for (Observable observeur : observeurs.get(path)) {
            observeur.update();
        }
    }

    public void unbind(String path) {
        annuaire.remove(path);
    }

    /**
     * Vérification des sources de la méthode lookup ici.
     */
    private Boolean canAccess(String src, String path) {
        if (src.contains(".controller.")) {
            return true;
        }
        if (src.contains("DBAccess") && path.contains("ArticleService")) {
            return false; // Exemple d'accès interdit
        }
        return true; // Parce que nous n'avons pas testé tous les cas
    }

    public Object lookup(String path) {
        String src = Thread.currentThread().getStackTrace()[2].getClassName();
        if (canAccess(src, path)) {
            return annuaire.get(path);
        }
        return null;
    }

    public void subscribe(Observable subscriber, String path) {
        if (!observeurs.containsKey(path)) {
            observeurs.put(path, new ArrayList<>());
        }
        if (!observeurs.get(path).contains(subscriber)) {
            observeurs.get(path).add(subscriber);
        }
    }

    public void unsubscribe(Observable subscriber, String path) {
        if (!observeurs.containsKey(path) || !observeurs.get(path).contains(subscriber)) {
            return;
        }
        observeurs.get(path).remove(subscriber);
    }

    public String getPathFromClassName(String className) {
        Optional<String> path = annuaire.keySet().stream()
                .filter(key -> key.endsWith("/" + className))
                .findFirst();
        if (path.isPresent()) {
            return path.get();
        }
        return null;
    }
}
