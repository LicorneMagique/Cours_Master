package fr.univlyon1.m2.tiw1.server;

import java.util.Map;

public interface ContextService {
    public void setComponents(Map<String, Object> components);
    public Object getComponent(String className);
}
