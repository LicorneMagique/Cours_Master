package fr.univlyon1.m2.tiw1.server;

import java.util.Map;

public class ContextServiceImpl implements ContextService {

    private Map<String, Object> components;

    public ContextServiceImpl() {
    }

    @Override
    public void setComponents(Map<String, Object> components) {
        this.components = components;
    }

    @Override
    public Object getComponent(String name) {
        return components.get(name);
    }
}
