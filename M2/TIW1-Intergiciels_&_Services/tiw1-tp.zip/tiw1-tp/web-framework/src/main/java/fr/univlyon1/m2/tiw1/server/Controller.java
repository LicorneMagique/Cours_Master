package fr.univlyon1.m2.tiw1.server;

import fr.univlyon1.m2.tiw1.server.Response;

import java.util.Map;

public interface Controller {
    Response<String> process(String commande, Map<String, Object> parametres);
}
