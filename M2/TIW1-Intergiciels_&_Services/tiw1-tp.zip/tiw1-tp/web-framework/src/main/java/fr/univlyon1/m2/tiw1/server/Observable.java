package fr.univlyon1.m2.tiw1.server;

public interface Observable {
    public void update();
}
