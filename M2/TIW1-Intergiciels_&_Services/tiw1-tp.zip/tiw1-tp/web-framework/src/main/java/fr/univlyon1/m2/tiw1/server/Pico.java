package fr.univlyon1.m2.tiw1.server;

import org.json.JSONArray;
import org.json.JSONObject;
import org.picocontainer.Characteristics;
import org.picocontainer.DefaultPicoContainer;
import org.picocontainer.MutablePicoContainer;
import org.picocontainer.behaviors.Caching;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class Pico {

    private final MutablePicoContainer picoContainer;
    private static Pico instance;

    private Pico() {
        // Récupération du fichier de config
        ClassLoader cl = getClass().getClassLoader();
        InputStream configStream = cl.getResourceAsStream("config.json");
        String configStr = null;
        try {
            configStr = new String(configStream.readAllBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        assert configStr != null;

        // Récupération des données (app + MVC = nos 4 variables)
        JSONObject applicationConfig = new JSONObject(configStr).getJSONObject("application-config");
        JSONArray businessComponents = applicationConfig.getJSONArray("business-components");
        JSONArray serviceComponents = applicationConfig.getJSONArray("service-components");
        JSONArray persistenceComponents = applicationConfig.getJSONArray("persistence-components");

        // Config app
        String keyName = "nomOrganisation";
        this.picoContainer = new DefaultPicoContainer(new Caching())
                .as(Characteristics.SDI).addComponent("ContextService", ContextServiceImpl.class)
                .addComponent(keyName, applicationConfig.getString("name"))
                .addComponent("annuaire", HashMap.class);

        // Config MVC
        var application = picoContainer.makeChildContainer();
        var persistence = application.makeChildContainer();
        var service = application.makeChildContainer();

        Map<String, Object> annuaire = (Map<String, Object>) picoContainer.getComponent("annuaire");
        annuaire.put("/" + keyName, application.getComponent(keyName));

        String basicPrefix = "_Component";
        String servicePrefix = "_Service" + basicPrefix;
        String businessPrefix = "_Controller" + servicePrefix;
        String persistencePrefix = "_Persistence" + servicePrefix;
        businessComponents.forEach(compo -> addComponentFromJsonToClassAndAnnuaire(compo, application, annuaire, businessPrefix));
        persistenceComponents.forEach(compo -> addComponentFromJsonToClassAndAnnuaire(compo, persistence, annuaire, persistencePrefix));
        serviceComponents.forEach(compo -> addComponentFromJsonToClassAndAnnuaire(compo, service, annuaire, servicePrefix));
    }

    private void addComponentFromJsonToClassAndAnnuaire(Object json,
                                                        MutablePicoContainer components,
                                                        Map<String, Object> annuaire,
                                                        String metaPrefix) {
        JSONObject jsonObject = (JSONObject) json;
        String name = jsonObject.getString("class-name") + metaPrefix;
        String path = jsonObject.getString("path");
        try {
            Class<?> clazz = Class.forName(name);
            components.addComponent(clazz);
            annuaire.put(path, components.getComponent(clazz));
            if (!jsonObject.has("params")) {
                return;
            }
            JSONArray params = jsonObject.getJSONArray("params");
            params.forEach(param -> {
                JSONObject jsonParam = (JSONObject) param;
                String paramName = jsonParam.getString("name");
                Object paramValue = jsonParam.get("value");
                annuaire.put(path + "/" + paramName, paramValue);
            });
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static MutablePicoContainer getPicoContainer() {
        if (instance == null) {
            instance = new Pico();
            instance.picoContainer.start();
            instance.picoContainer.getComponent(Map.class).values().forEach(c -> {
                if (c instanceof Initiable) {
                    ((Initiable) c).init();
                }
            });
        }
        return instance.picoContainer;
    }
}
