package fr.univlyon1.m2.tiw1.server;

import org.json.JSONObject;

public class Response<T> {
    
    private T content;
    private Integer status;

    public Response(Integer status) {
        this.content = null;
        this.status = status;
    }
    
    public Response(T content, Integer status) {
        this.content = content;
        this.status = status;
    }

    public T getContent() {
        return content;
    }

    public void setContent(T content) {
        this.content = content;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String toJSON() {
        return new JSONObject(this).toString();
    }

}
