# TIW6 projet 2021-2022 : course de tortues

- Maxime BUNEL p1914012
- Julien GIRAUD p1704709
- Diogenes MOLINARES p2019196
- Jérémy THOMAS p1702137

## Lancement de l'analyse sur la VM `192.168.76.139`

Notre script d'analyse utilise les données enregistrées afin de générer des fichiers de configurations "modèles" pour chaque course. Le résultat de ce traitement se trouve dans le répertoire `/home/p1914012/tortoise/configs`, aussi présent dans ce dépôt.

```bash
# Connexion à la VM
ssh -i key_tiw6_vm p1914012@192.168.76.139

# Analyse (nécessite quelques heures pour 25 Go de données)
/home/p1914012/tortoise/analyse.sh
```

## Lancement de la prédiction

La prédiction peut se faire diretement depuis la racine de ce dépôt à condition d'avoir installé `sklearn`, `orderedset`, `matplotlib` et `pickle` pour Python3.

```bash
# Depuis prediction.py pour spécifier le nom des paramètres 
python3 prediction.py --course <course> --id <id> --top <top> --pos1 <pos1> --pos2 <pos2> --pos3 <pos3> --temp <temp> --qual <qual> --deltatop <deltatop> 2> logs-prediction.txt
# Exemple
python3 prediction.py --course tiny --id 0 --top 27592 --pos1 2317728 --pos2 2317812 --pos3 2317896 --temp 19.110571253197488 --qual 0.3100529516794682 --deltatop 10 2> logs-prediction.txt

# Ou depuis prediction.sh avec l'ordre suivant pour les paramètres (la sortie erreur est déjà configurée sur logs-prediction.txt)
./prediction.sh <course> <id> <top> <pos1> <pos2> <pos3> <temp> <qual> <deltatop>
# Exemple
./prediction.sh tiny 0 27592 2317728 2317812 2317896 19.110571253197488 0.3100529516794682 10
```

<div style="page-break-after:always"></div>

## Explications sur l'analyse

### Enregistrement des données

Dans un premier temps nous avons utilisé un cron sur la VM pour enregistrer les données sans les traiter.

```bash
* * * * * for i in $(seq 60); do /usr/bin/python3 /home/p1914012/tortoise/cron.py; sleep 1; done
```

### Traitements des données : formattage

Nous avons commencé par rassembler les données de chaque tortue suivant ce format.

```json
{
    "id": "idTortue",
    "startTop": "le premier top connu",
    "positions": ["liste des positions"],
    "deplacements": ["liste des déplacements"],
    "deltas": ["liste des accélérations"],
    "metadata": {
        "top": {
            "qualite": "qualite top",
            "temperature": "temperature top",
            "index": "index de la position correspondante"
        }
    },
    "config": "détaillé partie suivante"
}
```

Ces données formatées sont enregistrées dans un répertoire `data-transformed`. Il contient un dossier par course et pour chaque course nous avons un fichier pour 100 tortues (ou 10 pour la course `tiny`).

```bash
$ ls -R data-transformed
data-transformed:
large  medium  small  tiny
data-transformed/large:
1000.json  1200.json  1500.json  1800.json  200.json  500.json  800.json
100.json   1300.json  1600.json  1900.json  300.json  600.json  900.json
1100.json  1400.json  1700.json  2000.json  400.json  700.json
data-transformed/medium:
100.json  200.json  300.json  400.json  500.json
data-transformed/small:
100.json
data-transformed/tiny:
10.json
```

### Traitement des données : configurations classiques

Nous avons utilisé les données formattées pour détecter la configuration des tortues non lunatiques et nous avons ajouté ces configurations dans le champ `config` de chaque tortue.

Les modèles de configurations sont les suivants.

```json
{
    "type": "reguliere",
    "pas": "le déplacement"
}
```

```json
{
    "type": "fatigue",
    "pas": "la valeur d'accélération",
    "pasSpecial": "la valeur de l'accélération spéciale, ou None",
    "count": "le nombre de répétitions du pas",
    "startTop": "un top à partir duquel le prochain déplacement est de 0"
}
```

```json
{
    "type": "cyclique",
    "cycle": ["tableau des déplacements du cycle"]
}
```

Les tortues sans configuration classique sont lunatiques.

```json
{
    "type": "lunatique"
}
```

### Traitement des données : configurations des tortues lunatiques

Pour les tortues lunatiques, nous avons parcouru les données de déplacements et ajouté les configurations locales (classiques) dans les données du `top` du champ `metadata` environ tous les 500 tops.

<div style="page-break-after:always"></div>

Par exemple :

```json
...
"metadata": {
    "45675": {
            "qualite": "0.345",
            "temperature": "12.7",
            "index": 42,
            "config": {
                "type": "reguliere",
                "pas": 12
            }
        }
}
```

Nous avons ensuite ajouté un champ `configs` dans la tortue avec les différentes configurations que nous avons détectées, indexé sur les identifiants de ces configurations.

```json
"configs": {
    "config_1": {
        "type": "reguliere",
        "pas": 12,
        "countConfig": "occurence dutilisation de la configuration"
    },
    "config_2": {
        "type": "reguliere",
        "pas": 7,
        "countConfig": 543
    },
    "config_3": {
        "type": "cyclique",
        "cycle": [4, 19, 13, 8],
        "countConfig": 
    }
}
```

Puis nous avons ajouté un champ `points` dans chaque tortue pour rassembler les données nécessaires pour la régression linéaire (qualité, température, configuration).

```json
"points": [
    (0.234, 17, "config_1"),
    (0.759, 34, "config_1"),
    (0.675, 6, "config_2"),
    (0.374, 23, "config_3")
]
```

Nous avons utilisé ces points avec `sklearn` pour générer un modèle de régression linéaire pour chaque tortue.

Enfin, pour chaque type de course nous avons parcouru les données de toutes les tortues et enregistré dans une variable leurs configurations avec éventuellement les modèles de régression linéaire.

```json
{
    "idTortue": {
        "config": "le champ 'config' de la tortue",
        "modele": "l'objet modèle de sklearn si la tortue est lunatique",
        "configs": "le champ 'configs' de la tortue si elle est lunatique"
    }
}
```

Nous avons enregistré ces variables de configuration dans le dossier `configs` sous forme de fichier avec `Pickle`.

### Prédiction : récupération des configurations

**Notre système de prediction prend comme hypothèse que le top et Delta Top sont compris dans la même configuration de température et qualité de repas.**

Lors de la prédiction nous chargeons les configurations des tortues avec `Pickle`.

Pour les tortues classiques il est trivial de retrouver leur configuration.

Pour les tortues lunatiques, nous essayons dans un premier temps à détecter quelle configuration est utilisée à partir des trois positions en entrée du programme. Si nous n'arrivons pas à identifier de configuration, nous utilisons le modèle de régression linéaire afin de déterminer la configuration la plus probable.

### Taux de prediction sur nos tests

En combinant la régression linéaire et la possibilité de détecter certains types de tortues, nous avons trouvé un taux de réussite de prediction proche du 95% sur les tortues lunatiques et 100% dans les autres cas, ceci en faisant des tests avec Delta top = 400.  
Le cas échéant sur les tortues lunatiques correspond au changement de qualité de repas et température entre le top et Delta Top demandé.

<div style="page-break-after:always"></div>

## Annexes

![Configurations d'une tortue lunatique de la course small](./images-regression-linaire/small-id-88.png)  
![Configurations d'une tortue lunatique de la course large](./images-regression-linaire/large-id-869.png)
