import os
import json
from orderedset import OrderedSet
from lunatique import addConfigFromFile, addDataForLinearRegressionToFiles

types = ["tiny", "small", "medium", "large"]
basepath = "/media/finalgo/Windows/Users/Finalgo/linux/tortoise/"
# basepath = "/home/p1914012/tortoise/"
# python3 analyse.py > logs-analyse.txt 2>&1 &


def loadDataFromFiles(type):
    data = dict()
    directory = basepath + type
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        f = open(filepath)
        content = json.load(f)
        top = content["tortoises"][0]["top"]
        data[top] = filepath
    values = [data[key] for key in sorted(data.keys())]
    return values


def loadDataFromFile(type):
    return json.load(open(basepath + type + "-data.json"))


def transformeDataFromResponses(responsesFile):
    doneIds = set()
    numberOfTurtle = None
    size = 100
    while True:
        data = dict()
        lastPrct = 0
        currentCount = 0
        for file in responsesFile:
            currentCount += 1
            prct = int((currentCount / responsesFile.__len__()) * 100)
            if prct > lastPrct + 10:
                print(str(prct) + " % de lecture des fichiers")
                lastPrct = prct
            response = json.load(open(file))
            qualite = response["qualite"]
            temperature = response["temperature"]
            top = response["tortoises"][0]["top"]
            numberOfTurtle = response["tortoises"].__len__()
            for turtle in response["tortoises"]:
                id = turtle["id"]
                if id in doneIds or (data.keys().__len__() > size - 1 and not id in data.keys()):
                    continue
                position = turtle["position"]
                if not id in data.keys():
                    data[id] = {
                        "id": id,
                        "startTop": top,
                        "positions": [position],
                        "deplacements": [],
                        "deltas": [],
                        "metadata": {
                            top: {
                                "qualite": qualite,
                                "temperature": temperature,
                                "index": 0
                            },
                        }
                    }
                else:
                    lastPosition = data[id]["positions"][-1]
                    deplacement = position - lastPosition
                    data[id]["positions"].append(position)
                    if data[id]["deplacements"].__len__() > 1:
                        lastDeplacement = data[id]["deplacements"][-1]
                        delta = deplacement - lastDeplacement
                        data[id]["deltas"].append(delta)
                    data[id]["deplacements"].append(deplacement)
                    data[id]["metadata"][top] = {
                        "qualite": qualite,
                        "temperature": temperature,
                        "index": data[id]["positions"].__len__() - 1
                    }
                if file == responsesFile[-1]:
                    print("Ajout des données de config et nettoyage des informations en trop")
                    addConfig(data[id])
                    cleanDataIfNotNeeded(data[id])
        for id in data.keys():
            doneIds.add(id)
        print(str((doneIds.__len__() / numberOfTurtle) * 100) + " % du type " + type)
        dataPath = basepath + "data-transformed/" + type + "/" + str(doneIds.__len__()) + ".json"
        os.makedirs(os.path.dirname(dataPath), exist_ok=True)
        open(dataPath, "w") \
            .write(json.dumps(data))
        if doneIds.__len__() == numberOfTurtle:
            break


# Méthode de correction d'une erreur de notre analyse,
# n'est plus nécessaire depuis la correction du code.
def addMissingMovesFromResponses(responsesFile):
    directory = basepath + "data-transformed/" + type
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        content = json.load(open(filepath))
        lastPrct = 0
        currentCount = 0
        for file in responsesFile:
            currentCount += 1
            prct = int((currentCount / responsesFile.__len__()) * 100)
            if prct > lastPrct + 10:
                print(str(prct) + " % de lecture des fichiers")
                lastPrct = prct
            file.seek(0)
            response = json.load(file)
            for turtle in response["tortoises"]:
                id = str(turtle["id"])
                if id not in content.keys() or not content[id]["config"]["type"] == "lunatique":
                    continue
                position = turtle["position"]
                content[id]["positions"].append(position)
                if content[id]["positions"].__len__() > 1:
                    lastPosition = content[id]["positions"][-1]
                    deplacement = position - lastPosition
                    content[id]["deplacements"].append(deplacement)
                if content[id]["deplacements"].__len__() > 1:
                    lastDeplacement = content[id]["deplacements"][-1]
                    delta = deplacement - lastDeplacement
                    content[id]["deltas"].append(delta)
        open(filepath, "w") \
            .write(json.dumps(content))


def removeBadDataFromTransformedData(type):
    directory = basepath + "data-transformed/" + type
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        f = open(filepath)
        content = json.load(f)
        for turtle in content.values():
            if turtle["config"]["type"] == "lunatique":
                turtle["positions"] = []
                turtle["deplacements"] = []
                turtle["deltas"] = []
                turtle["metadata"] = []
        open(filepath, "w")\
            .write(json.dumps(content))


def cleanDataIfNotNeeded(turtle):
    if not turtle["config"]["type"] == "lunatique":
        turtle["positions"] = turtle["positions"][:1000]
        turtle["deplacements"] = turtle["deplacements"][:999]
        turtle["deltas"] = turtle["deltas"][:998]
        authorizedTops = list(turtle["metadata"].keys())[:1000]
        metadata = dict()
        for top in authorizedTops:
            metadata[top] = turtle["metadata"][top]
        turtle["metadata"] = metadata


def loadTransformedDataFromFile(type):
    return json.load(open(basepath + type + "-data-transformed.json"))


def transformeData(type):
    data = loadDataFromFiles(type)
    transformeDataFromResponses(data)


def addMissingMovesToTransformedData(type):
    data = loadDataFromFiles(type)
    addMissingMovesFromResponses(data)


def ilsSeSuivent(tops, startIndex, length):
    for i in range(length):
        if not tops[startIndex + i] + 1 == tops[startIndex + i + 1]:
            return False
    return True


def isTurtleReguliere(turtle):
    deplacements = list(turtle["deplacements"])
    start = 1
    tops = [int(top) for top in turtle["metadata"].keys()]
    while start < deplacements.__len__():
        # Détection saut de top
        if not ilsSeSuivent(tops, start - 1, 3):
            continue
        moves = {deplacements[start + i] for i in range(2)}
        if not moves.__len__() == 1:
            return False
        start += 500
    return True


# Retourne les index des tops les plus espacés tels qu'il n'y a pas de saut
def getMaxConsecutifTops(turtle):
    taille = 0
    minIndex = 0
    maxIndex = 0
    tops = [int(top) for top in turtle["metadata"].keys()]
    for index in range(tops.__len__() - 2):
        if ilsSeSuivent(tops, index, 2):
            taille += 1
        elif taille > maxIndex - minIndex:
            maxIndex = index
            minIndex = index - taille
            taille = 0

    if minIndex == maxIndex:
        maxIndex = tops.__len__() - 1
    return (minIndex, maxIndex + 3)


def isTurtleFatigue(deltas):
    deltasSet = OrderedSet(deltas)
    result = deltasSet.__len__() == 4 and \
             deltasSet.__getitem__(0) + deltasSet.__getitem__(2) == 0 and \
             deltasSet.__getitem__(1) + deltasSet.__getitem__(3) == 0
    return result


def isTurtleCyclique(deplacements, cycle):
    for i in range(deplacements.__len__() - 1):
        indexCycle = cycle.index(deplacements[i])
        indexNextCycle = (indexCycle + 1) % cycle.__len__()
        if not deplacements[i + 1] == cycle[indexNextCycle]:
            return False
    return True


def addConfig(turtle):
    (min, max) = getMaxConsecutifTops(turtle)
    deplacements = turtle["deplacements"][min:max - 2] # 2 d'écart avec les tops sur l'index de droite
    deltas = turtle["deltas"][min - 1:max - 4] # 1 et 4 d'écart ici
    cycle = list(OrderedSet(deplacements))
    if isTurtleReguliere(turtle):
        turtle["config"] = {
            "type": "reguliere",
            "pas": deplacements[0]
        }
    elif isTurtleFatigue(deltas):
        if id == 1:
            True
        start = deplacements.index(0)
        pas = deplacements[start + 1]
        stop = deplacements[start + 1:].index(0) + start
        count = deltas[start - 1:stop].count(pas) # Attention il y a 1 de décalage entre déplacements et deltas
        pasSpecial = deltas[start - 1:stop][count]
        startTop = list(turtle["metadata"].keys())[min + start]
        turtle["config"] = {
            "type": "fatigue",
            "pas": pas,
            "pasSpecial": pasSpecial,
            "count": count,
            "startTop": startTop,  # un top à partir duquel le prochain déplacement est de 0
        }
    elif isTurtleCyclique(deplacements, cycle):
        startTop = list(turtle["metadata"].keys())[min]
        turtle["config"] = {
            "type": "cyclique",
            "cycle": cycle,
            "startTop": startTop,  # un top à partir duquel le déplacement est au début du cycle
        }
    else:
        turtle["config"] = {
            "type": "lunatique"
        }

# Analyse ici
for type in types:
    # Génération des données du répertoire data-transformed
    transformeData(type)

    # Suppression des données en trop pour les tortues non lunatiques
    removeBadDataFromTransformedData(type)

    # Analyse des tortues lunatiques (récupération des points pour la régression linéaire)
    addDataForLinearRegressionToFiles(type)

    # Génération des fichiers de configuration "modèles"
    addConfigFromFile(type)
