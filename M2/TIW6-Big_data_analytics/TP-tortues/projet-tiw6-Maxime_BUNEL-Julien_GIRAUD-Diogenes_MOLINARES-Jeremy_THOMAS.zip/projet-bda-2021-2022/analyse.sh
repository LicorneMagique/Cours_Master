#!/bin/bash
python3 analyse.py > logs-analyse.txt 2>&1 &
