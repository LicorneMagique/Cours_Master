import os
import json
from orderedset import OrderedSet
import matplotlib.pyplot as plt
from sklearn import svm
import pickle


# pip3 install --proxy=http://proxy.univ-lyon1.fr:3128/ sklearn orderedset matplotlib


types = ["tiny", "small", "medium", "large"]
basepath = "/media/finalgo/Windows/Users/Finalgo/linux/tortoise/"
# basepath = "/home/p1914012/tortoise/"


def ilsSeSuivent(tops, startIndex, length):
    for i in range(length):
        if not tops[startIndex + i] + 1 == tops[startIndex + i + 1]:
            return False
    return True


def addMetadataForTurtleReguliere(turtle):
    deplacements = list(turtle["deplacements"])
    start = 1
    tops = [int(top) for top in turtle["metadata"].keys()]
    while start < deplacements.__len__():
        # Détection saut de top
        if ilsSeSuivent(tops, start - 1, 3):
            moves = {deplacements[start + i] for i in range(2)}
            if moves.__len__() == 1:
                top = list(turtle["metadata"])[start]
                pas = deplacements[start]
                turtle["metadata"][top]["config"] = {
                    "type": "reguliere",
                    "pas": pas
                }
        start += 500
    True


def addMetadataForTurtleFatigue(turtle):
    deltas = turtle["deltas"]
    tops = [int(top) for top in turtle["metadata"].keys()]
    start = 2
    while start < deltas.__len__():
        deltasSet = OrderedSet()
        decalage = 0
        while decalage < 500 and start + decalage + 1 < deltas.__len__():
            if deltasSet.__len__() == 4 and deltas[decalage + start + 1] == deltasSet.__getitem__(3):
                break
            if deltasSet.__len__() > 4:
                break
            if decalage > 4 and deltasSet.__len__() == 2 and sum(deltasSet) == 0:
                break
            deltasSet.add(deltas[decalage + start])
            decalage += 1
        if deltasSet.__len__() == 4 or deltasSet.__len__() == 2:
            if deltasSet.__len__() == 4:
                fatigue = deltasSet.__getitem__(0) + deltasSet.__getitem__(2) == 0 and \
                     deltasSet.__getitem__(1) + deltasSet.__getitem__(3) == 0
            else:
                fatigue = sum(deltasSet) == 0
            if fatigue:
                deplacements = turtle["deplacements"][start - 1:]
                if 0 in deplacements:
                    localStart = deplacements.index(0)
                    pas = deplacements[localStart + 1]
                    if 0 in deplacements[localStart + 1:]:
                        localStop = deplacements[localStart + 1:].index(0) + localStart + 1
                        if ilsSeSuivent(tops, start + localStart, localStop - localStart):
                            localDeltas = turtle["deltas"][start - 2 + localStart:start + localStop - 2]
                            count = localDeltas.count(pas)
                            try:
                                pasSpecial = localDeltas[count]
                            except Exception:
                                print(1)
                            if pasSpecial + pas == 0:
                                pasSpecial = None
                            startTop = list(turtle["metadata"].keys())[start - 1 + localStart]
                            top = list(turtle["metadata"])[start]
                            turtle["metadata"][top]["config"] = {
                                "type": "fatigue",
                                "pas": pas,
                                "pasSpecial": pasSpecial,
                                "count": count,
                                "startTop": startTop,  # un top à partir duquel le prochain déplacement est de 0
                            }
        start += 500
    True


def addMetadataForTurtleCyclique(turtle):
    deplacements = turtle["deplacements"]
    tops = [int(top) for top in turtle["metadata"].keys()]
    start = 0
    while start < deplacements.__len__():
        movesSet = OrderedSet()
        moves = []
        decalage = 0
        stop = True
        while decalage < 500 and start + decalage < deplacements.__len__():
            if movesSet.__len__() > 900:
                break
            if moves.__len__() > 2 and moves.__len__() / 2 == movesSet.__len__():
                stop = False
                break
            move = deplacements[decalage + start]
            movesSet.add(move)
            moves.append(move)
            decalage += 1
        if not stop:
            deltasSet = OrderedSet(turtle["deltas"][start + decalage:start + decalage + movesSet.__len__()])
            fatigue = deltasSet.__len__() == 4 and \
                      deltasSet.__getitem__(0) + deltasSet.__getitem__(2) == 0 and \
                      deltasSet.__getitem__(1) + deltasSet.__getitem__(3) == 0
            if not fatigue:
                firstHalfMoves = moves[:movesSet.__len__()]
                secondHalfMoves = moves[movesSet.__len__():]
                cyclique = firstHalfMoves == secondHalfMoves == list(movesSet)
                if cyclique:
                    if ilsSeSuivent(tops, start + decalage, moves.__len__()):
                        startCycleIndex = moves.index(min(moves))
                        cycle = []
                        for i in range(movesSet.__len__()):
                            cycle.append(firstHalfMoves[(i + startCycleIndex) % movesSet.__len__()])
                        top = list(turtle["metadata"])[start + decalage]
                        startTop = list(turtle["metadata"].keys())[start + decalage + startCycleIndex]
                        turtle["metadata"][top]["config"] = {
                            "type": "cyclique",
                            "cycle": cycle,
                            "startTop": startTop,  # un top à partir duquel le prochain déplacement est de 0
                        }
        start += 500
    True


def addPointsAndConfigsToTurtle(turtle):
    tmpConfigs = OrderedSet()
    configs = dict()
    points = []
    for meta in turtle["metadata"].values():
        if "config" in meta:
            config = dict()
            for key in ["type", "pas", "pasSpecial", "count", "cycle"]:
                if key in meta["config"]:
                    config[key] = meta["config"][key]
            tmpKeyConfig = json.dumps(config)
            if tmpKeyConfig not in tmpConfigs:
                tmpConfigs.add(tmpKeyConfig)
                key = "config_" + str(tmpConfigs.index(tmpKeyConfig) + 1)
                configs[key] = meta["config"]
                configs[key]["countPoints"] = 0
            key = "config_" + str(tmpConfigs.index(tmpKeyConfig) + 1)
            points.append((meta["qualite"], meta["temperature"], key))
            configs[key]["countPoints"] += 1
    turtle["configs"] = configs
    turtle["points"] = points
    if configs.__len__() == 1:
        print("Problème sur la tortue " + str(turtle["id"]) + ", on suppose qu'elle est " + turtle["configs"]["config_1"]["type"])
        correctionError(turtle)


def correctionError(turtle):
    if turtle["configs"].__len__() == 1 and \
        turtle["configs"]["config_1"]["type"] == "fatigue" and \
        turtle["configs"]["config_1"]["pasSpecial"] is None:

        turtle["config"] = {
            "type": "fatigue",
            "pas": turtle["configs"]["config_1"]["pas"],
            "pasSpecial": turtle["configs"]["config_1"]["pasSpecial"],
            "count": turtle["configs"]["config_1"]["count"],
            "startTop": turtle["configs"]["config_1"]["startTop"],  # un top à partir duquel le prochain déplacement est de 0
        }
        turtle.pop("configs")
        turtle.pop("points")

    elif turtle["configs"].__len__() == 1 and \
            turtle["configs"]["config_1"]["type"] == "cyclique":

        turtle["config"] = {
            "type": "cyclique",
            "cycle": turtle["configs"]["config_1"]["cycle"],
            "startTop": turtle["configs"]["config_1"]["startTop"]
        }
        turtle.pop("configs")
        turtle.pop("points")


def addDataForLinearRegressionToTurtle(turtle):
    addMetadataForTurtleReguliere(turtle)
    addMetadataForTurtleFatigue(turtle)
    addMetadataForTurtleCyclique(turtle)
    addPointsAndConfigsToTurtle(turtle)


def addDataForLinearRegressionToFile(content):
    for turtle in content.values():
        if turtle["config"]["type"] == "lunatique":
            addDataForLinearRegressionToTurtle(turtle)
    True


def addDataForLinearRegressionToFiles(type):
    directory = basepath + "data-transformed/" + type
    for filename in os.listdir(directory):
        print("Fichier " + filename)
        filepath = os.path.join(directory, filename)
        f = open(filepath, "r")
        content = json.load(f)
        f.close()
        addDataForLinearRegressionToFile(content)
        f = open(filepath, "w")
        print("Enregistrement du nouveau " + filename)
        json.dump(content, f)
        f.close()


def addImagesToFiles(type):
    directory = basepath + "data-transformed/" + type
    for filename in os.listdir(directory):
        print("Fichier " + filename)
        filepath = os.path.join(directory, filename)
        f = open(filepath, "r")
        content = json.load(f)
        for turtle in content.values():
            if turtle["config"]["type"] == "lunatique":
                getPlotFromTurtle(turtle, type)


def checkPasSpecial(turtle):
    if turtle["config"]["type"] == "lunatique":
        print(1)
        for config in turtle["configs"].values():
            if config["type"] == "fatigue":
                startTop = config["startTop"]
                startIndex = turtle["metadata"][startTop]["index"]
                pas = config["pas"]
                pasSpecial = config["pasSpecial"]
                maxNumber = config["count"] * 2 + 2
                countPas = turtle["deltas"][startIndex:startIndex + maxNumber].count(pas)
                countPasSpecial = turtle["deltas"][startIndex:startIndex + maxNumber].count(pasSpecial)
                if countPas <= countPasSpecial:
                    print("problème lunatique " + str(turtle["id"]))
        # pas = turtle["config"]["pas"]
        # pasSpecial = turtle["config"]["pasSpecial"]
        # countPas = turtle["deplacements"].count(pas)
        # countPasSpecial = turtle["deplacements"].count(pasSpecial)
        # if countPas < countPasSpecial:
        #     print(1)
    elif "pasSpecial" in turtle["config"]:
        pas = turtle["config"]["pas"]
        pasSpecial = turtle["config"]["pasSpecial"]
        countPas = turtle["deltas"].count(pas)
        countPasSpecial = turtle["deltas"].count(pasSpecial)
        if countPas <= countPasSpecial:
            print(1)
            pasSpecial = None
            maxNumber = turtle["config"]["count"] * 2 + 2
            for i in range(maxNumber):
                if turtle["deltas"][i] not in [pas, - pas]:
                    pasSpecial = abs(turtle["deltas"][i])
            turtle["config"]["pasSpecial"] = pasSpecial


def getPlotFromTurtle(turtle, type):
    colors = ['red', 'green', 'blue', 'gray', "magenta", "pink", "brown"]
    i = 0
    id = str(turtle["id"])
    for config in turtle["configs"]:
        x = [point[0] for point in turtle["points"] if point[2] == config]
        y = [point[1] for point in turtle["points"] if point[2] == config]
        color = colors[i]
        i += 1
        plt.scatter(x, y, c=color)
    plt.xlabel('Qualité dernier repas')
    plt.ylabel('Température')
    plt.savefig(basepath + "images/" + type + "/" + id + ".png")
    plt.title("Points régression linéaire tortue " + id)


def addConfigFromFile(type):
    directory = basepath + "data-transformed/" + type
    configFilePath = basepath + "configs/" + type + "-config.p"
    config = dict()
    for filename in os.listdir(directory):
        print("Fichier " + filename)
        filepath = os.path.join(directory, filename)
        f = open(filepath, "r")
        content = json.load(f)
        f.close()
        for turtle in content.values():
            addConfig(turtle, config)
    pickle.dump(config, open(configFilePath, "wb"))


def addConfig(turtle, config):
    if turtle["config"]["type"] == 'lunatique':
        x = []
        y = []

        for point in turtle["points"]:
            x.append([point[0], point[1]])
            indexConfig = list(turtle["configs"]).index(point[2])
            y.append(indexConfig)

        model_SVR = svm.SVR(kernel='linear', gamma='auto')
        # training
        model_SVR.fit(x, y)
        config[turtle["id"]] = {
            "config": turtle["config"],
            "modele": model_SVR,
            "configs": turtle["configs"]
        }
    else:
        turtleId = turtle["id"]
        config[turtleId] = {
            "config": turtle["config"]
        }

'''
for type in types:
    print("Type " + type)
    addDataForLinearRegressionToFiles(type)
    addImagesToFiles(type)
    checkPasSpecialFromFile(type)
    addConfigFromFile(type)
'''
