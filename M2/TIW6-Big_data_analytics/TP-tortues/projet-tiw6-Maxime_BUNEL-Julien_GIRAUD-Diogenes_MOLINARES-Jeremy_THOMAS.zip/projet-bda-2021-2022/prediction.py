import pickle
import os
import json
import sys

types = ["tiny", "small", "medium", "large"]
# basepath = "/media/finalgo/Windows/Users/Finalgo/linux/tortoise/"
basepath = "./"
# basepath = "/home/p1914012/tortoise/"
configPrediction = dict()


# Charge les "modèles" en mémoire et les retourne
def getConfigPrediction(course):
    if configPrediction.__len__() == 0:
        for type in types:
            configFilePath = basepath + "configs/" + type + "-config.p"
            f = open(configFilePath, "rb")
            content = pickle.load(f)
            configPrediction[type] = content
    config = configPrediction[course]
    return config


def getLunatiqueConfig(pos1, pos2, pos3, qual, temp, config):
    dep1 = pos2 - pos1
    dep2 = pos3 - pos2
    delta = dep2 - dep1

    # Cas régulière
    if delta == 0:
        for conf in config["configs"].values():
            if conf["type"] == "reguliere" and conf["pas"] == dep1:
                return conf

    # Cas cyclique
    for conf in config["configs"].values():
        # parcourir le tableau de cycle et trouver si v1 est present dans le tableau
        if conf["type"] == "cyclique" and dep1 in conf["cycle"]:
            # dep2 prochain élément du cycle
            indexDep2 = conf["cycle"].index(dep1) + 1
            cycleSize = conf["cycle"].__len__()
            nextCycleDep = conf["cycle"][indexDep2 % cycleSize]
            # si oui, trouver si v2 est apres v1 (en prenant en compte que v1 peut etre le dernier element et v2 est le premier)
            if dep2 == nextCycleDep:
                return conf

    # Cas fatiguée
    configs = [conf for conf in config["configs"].values() if conf["type"] == "fatigue" and (
            conf["pas"] == abs(delta) or conf["pasSpecial"] == abs(delta))]
    if configs.__len__() == 1:
        return configs[0]

    # Prédiction par régression linéaire ici, si on sait vraiment pas...
    pred = config["modele"].predict([[qual, temp]])
    avgIndex = (pred.min() + pred.max()) / 2
    configsIndex = [list(config["configs"].values()).index(conf) for conf in configs]
    index = getBestIndexFromLinearRegression(avgIndex, configsIndex)
    configKey = list(config["configs"])[index]
    return config["configs"][configKey]


def getBestIndexFromLinearRegression(avgIndex, configsIndex):
    diff = {index: abs(avgIndex - index) for index in configsIndex}
    minDiff = min(diff.values())
    for key in diff:
        if diff[key] == minDiff:
            return key


def doPrediction(type, id, top, pos1, pos2, pos3, temp, qual, deltatop):
    config = getConfigPrediction(type)[id]
    subConfig = config["config"]

    if subConfig["type"] == "lunatique":
        subConfig = getLunatiqueConfig(pos1, pos2, pos3, qual, temp, config)

    if subConfig["type"] == "reguliere":
        return pos1 + (subConfig["pas"] * deltatop)
    elif subConfig["type"] == "cyclique":
        cycle = subConfig["cycle"]
        tailleCycle = cycle.__len__()
        posDebutCycle = cycle.index(pos2 - pos1)
        accumul = 0
        if posDebutCycle + deltatop > tailleCycle:
            # decouper en 3 morceaux
            # 1=> compris depuis le debut dy cycle jusqu'a la fin du tableau
            premierMorceau = cycle[posDebutCycle: tailleCycle]
            accumul += sum(premierMorceau)
            # 2 => la somme du tableau de cycles * qte de fois qu'on fait le parcours complet
            nbElementsATraiter = (deltatop - premierMorceau.__len__())
            nbParcoursComplets = int(nbElementsATraiter / tailleCycle)
            if nbParcoursComplets > 0:
                accumul += sum(cycle) * nbParcoursComplets

            accumul += sum(cycle[0: (nbElementsATraiter % tailleCycle)])
        else:
            # 3 => le 3eme morceaux
            accumul += sum(cycle[posDebutCycle: posDebutCycle + deltatop])
        return pos1 + accumul
    elif subConfig["type"] == "fatigue":
        conf = subConfig

        if deltatop == 0:
            return pos1

        # creer un tableau de cycle d'accélération
        cycle = []
        pasSpecial = conf["pasSpecial"]
        for i in range(conf["count"]):
            cycle.append(conf["pas"])
        if pasSpecial is not None:
            cycle.append(pasSpecial)

        for i in range(conf["count"]):
            cycle.append(-conf["pas"])
        if pasSpecial is not None:
            cycle.append(- pasSpecial)

        vitesse = pos2 - pos1
        posDebutCycle = ((top - int(conf["startTop"])) % cycle.__len__())

        # on a deja trouve la premiere valeur a partir des donnees recuperes depuis l'appel a la methode
        accumul = vitesse
        count = 1
        while True:
            if count == deltatop:
                break
            vitesse = cycle[posDebutCycle] + vitesse
            accumul += max(0, vitesse)
            posDebutCycle += 1
            count += 1
            if posDebutCycle >= cycle.__len__():
                posDebutCycle = 0
        return pos1 + accumul
    else:
        return 0


# Méthode de test "maison" qui nous donne un pourcentage de réussite de prédiction sur quelques données.
# Cette méthode n'affiche des valeurs que si elles sont inférieures à 100 %.
def testTurtle(turtle, type):
    i = 100
    predictionsOk = 0.001
    predictionNotOk = 0.001
    while i < turtle["positions"].__len__():
        top = int(list(turtle["metadata"])[i - 10])
        pos1 = turtle["positions"][i - 10]
        pos2 = turtle["positions"][i - 9]
        pos3 = turtle["positions"][i - 8]
        deltatop = 10
        temp = turtle["metadata"][str(top)]["temperature"]
        qual = turtle["metadata"][str(top)]["qualite"]

        prediction = doPrediction(type, turtle["id"], top, pos1, pos2, pos3, temp, qual, deltatop)
        if not prediction == turtle["positions"][i]:
            predictionNotOk += 1
            print(str((predictionsOk / (predictionsOk + predictionNotOk) * 100)) + " % ok")
        else:
            predictionsOk += 1
        i += 400


def test():
    for type in types:
        directory = basepath + "data-transformed/" + type
        for filename in os.listdir(directory):
            print("Fichier " + filename)
            filepath = os.path.join(directory, filename)
            f = open(filepath, "r")
            content = json.load(f)
            for turtle in content.values():
                testTurtle(turtle, type)


# test()

def main(argv):
    help = "python3 prediction.py --course <course> --id <id> --top <op> --pos1 <pos1> --pos2 <pos2> --pos3 <pos3> --temp <temp> --qual <qual> --deltatop <deltatop>"
    try:
        for i in range(argv.__len__() - 1):
            opt = argv[i]
            arg = argv[i+1]
            if opt == "--course":
                course = arg
            elif opt == "--id":
                id = int(arg)
            elif opt == "--top":
                top = int(arg)
            elif opt == "--pos1":
                pos1 = int(arg)
            elif opt == "--pos2":
                pos2 = int(arg)
            elif opt == "--pos3":
                pos3 = int(arg)
            elif opt == "--temp":
                temp = float(arg)
            elif opt == "--qual":
                qual = float(arg)
            elif opt == "--deltatop":
                deltatop = int(arg)

        prediction = doPrediction(course, id, top, pos1, pos2, pos3, temp, qual, deltatop)
        print(prediction)
    except Exception:
        print(help)
        sys.exit(2)


if __name__ == "__main__":
   main(sys.argv[1:])

