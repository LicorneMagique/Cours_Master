#!/bin/bash
python3 prediction.py --course $1 --id $2 --top $3 --pos1 $4 --pos2 $5 --pos3 $6 --temp $7 --qual $8 --deltatop $9 2> logs-prediction.txt
