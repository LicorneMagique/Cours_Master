import requests
import json
from datetime import datetime


def get_data(url):
    r = requests.get(url)
    return json.loads(r.text)


def write_data(file, data):
    f = open(file, "w")
    f.write(json.dumps(data))
    f.close()


def log_error(file, error):
    f = open(file, "a")
    f.write(error)
    f.close()


volumes = ['tiny', 'small', 'medium', 'large']
path_base = '/home/p1914012/tortoise/'
url_base = 'http://tortues.ecoquery.os.univ-lyon1.fr/race/'
for volume in volumes:
    try:
        tortoises = get_data(url_base + volume)
        top = tortoises['tortoises'][0]['top']
        write_data(path_base + volume + '/' + 'collected_' + volume + '_' + str(top) + '.json', tortoises)
    except Exception as e:
        now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        log_error(path_base + 'python_log_error.txt', "\n" + now + " : " + str(e) + "\n")
