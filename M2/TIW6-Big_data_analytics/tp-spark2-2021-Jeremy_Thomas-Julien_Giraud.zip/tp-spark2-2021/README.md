# TP Spark 2021 - Partitionnement

Dans ce TP on va pousser plus loin l'utilisation de Spark et HDFS en travaillant
sur un volume de données plus important. On souhaite en particulier pouvoir
rapidement sélectionner des sources correspondant à une zone du ciel proche d'un
certain point. Il s'agit donc d'une sorte d'index basé sur la position des
sources sur la sphère céleste. On s'appuiera pour cela sur les coordonnées
`DECL`
([déclinaison](<https://fr.wikipedia.org/wiki/D%C3%A9clinaison_(astronomie)>)) et
`RA` ([ascension droite](https://fr.wikipedia.org/wiki/Ascension_droite)). On
souhaite être capable de découper la sphère celeste en pseudo rectangles
correspondant à chacun à une paire d'intervalles: un pour `DECL` et un autre
pour `RA`. On créera ensuite un répertoire par rectangle et on rangera les
différentes observations (lignes dans les fichiers `Source`) dans le répertoire
correspondant à son rectangle. Les répertoires vont ainsi former une sorte
d'index: pour accéder à une observation à partir de ses coordonnées, on choisira
d'abord le bon rectangle, puis il restera a lire uniquement les observations de
ce rectangle au lieu de lire toutes les observations.

## Note

Compiler et envoyer notre code scala sur la VM :

```shell
# cd tp-spark2-2021
# ssh-add UE-INF2339M_cle_ssh_p1704709.pem

sbt -java-home ~/.jdks/corretto-1.8.0_312/ assembly
scp ./target/scala-2.11/SparkTPPartitionnement-assembly-1.0.jar p1704709@192.168.76.143:/home/p1704709

# Sauf que notre VM a des problèmes avec Scala donc on utilise celle de Maxime
sbt -java-home ~/.jdks/corretto-1.8.0_312/ assembly && scp ./target/scala-2.11/SparkTPPartitionnement-assembly-1.0.jar p1914012@192.168.76.139:/home/p1914012/julien

# Sur la vm
# ssh p1704709@192.168.76.143
# cd p1704709
hdfs dfs -rm -r /user/p1914012/julien/output /user/p1914012/indexed-julien
spark-submit --class SparkPartitionnement ./SparkTPPartitionnement-assembly-1.0.jar hdfs:///tp-data/Source/Source-001.csv 50 true 42 false /user/p1914012/julien/output
```

## Rendu

Ce TP est à rendre pour le **14/11/2021**. Il est à réaliser en binôme avec les
binômes attribués au TP précédent. Il est demandé de déposer un fichier .zip sur
tomuss dans la case TP_SPARK2. Cette archive comprendra:

- Le code source
- Un fichier COMPTE_RENDU.md complété avec en particulier:

  - Les étudiants du binôme (repris depuis le fichier etudiants.yml)
  - les problèmes qui se sont posés et les solutions apportées
  - les extraits pertinents du code source pertinents pour illustrer les solutions

## Code fourni

Ce projet contient la correction du tp de découverte Spark qui peut être
utilisée comme point de départ pour ce TP. Dans ce cas, faite un _fork_ de ce
projet dans votre espace forge et partagez ce fork avec votre binôme. Il est
également possible de partir de votre version du TP découverte. Dans ce cas,
partez directement de ce projet.

Le code Scala contient également un fichier `TIW6RDDUtils.scala` qui sera utile pour écrire un RDD dans plusieurs fichiers (voir 3. ci-dessous).

## Données

On commencera par tester le fonctionnement du code sur le _source-sample_.
Une fois celui-ci fonctionnel, on pourra tester sur le fichier `hdfs:///tp-data/Source/Source-001.csv`.

Si vous utilisez Scala avec la méthode basée sur `TIW6RDDUtils`, vous pouvez tester sur le répertoire complet `hdfs:///tp-data/Source`.

ATTENTION: tuez votre job si son temps d'exécution dépasse 15min (vous n'êtes pas tous seuls sur le cluster).

## Mise en oeuvre

Le travail à faire peut être découpé en plusieurs étapes:

1. Découper le ciel en _n_ bandes correspondant à un intervalle de `DECL`. Par
   exemple, supposons que les valeurs de `DECL` s'étalent de _-0.3_ à _0.7_ on
   peut découper la sphère en 20 bandes de d'épaisseur _0.05_ chacune. Pour
   cela, on attribue un numéro à chaque bande et on ajoute à chaque source un
   attribut `part_decl` contenant le numéro de la bande dans laquelle sera
   placée cette observation. Remarque: pour pouvoir attribuer un numéro de bande
   à une valeur de `DECL`, il faut connaître en plus les valeurs min et max de
   `DECL` ainsi que le nombre total de bandes désiré.
2. Redécouper chaque bande en rectangles correspondant à des intervalles de
   `RA`. Comme il y aura plus d'observations dans les bandes près de l'équateur
   que dans les bandes près des pôles, il est est peu pertinent de fixer la
   taille de l'intervalle de manière identique sur toutes les bandes. On va à la
   place adapter cette taille pour chaque bande. Pour cela on fixe un nombre
   objectif _k_ d'observations par rectangle. On ajustera le nombre de
   rectangles selon le nombre d'observations comptées dans la bande. On
   supposera que les observations sont réparties de manière uniforme au sein
   d'une bande (mais on prendra bien en compte les valeurs min et max de `RA` au
   sein de la bande). Si _m_ est le nombre de rectangles dans une bande et _p_
   le nombre d'observations dans la bande complète, on veut que _k(m-1) ≤ p ≤
   km_. On ajoute alors à chaque observation un attribut `part_ra` indiquant le
   numéro du rectangle au sein de la bande.
   Remarque: on peut, au choix, placer les attributs directement dans le tableau de valeurs de chaque observation, ou bien construire une structure de la forme `((part_decl, part_ra), observation)` ce qui permet d'utiliser la paire `(part_decl, part_ra)` comme clé dans des opérations `xxxByKey`.
3. Sauvegarder le contenu de chaque rectangle dans un répertoire HDFS dont le
   nom comprendra le numéro de la bande (`part_decl`) et celui du rectangle dans
   la bande (`part_ra`). Par exemple, si `part_decl` vaut _3_ et `part_ra` vaut _6_, le répertoire pourrait s'appeler `indexed/3-6/`.

   Pour cela, on peut constituer un RDD pour chaque rectangle par filtrage, puis sauver ce RDD. On prendra soin de faire que le contenu des fichiers de ces répertoires soit au format csv comme pour les fichiers `Source` initiaux.
   Le défaut de cette approche est qu'il est nécessaire de filtrer la collection des sources pour _chaque_ fichier de sortie. Si cette approche est utilisée, il est important de lancer le partionnement sur une source de taille modérée, par exemple `hdfs:///tp-data/Source/Source-001.csv`, sinon le temps d'écriture sera trop long (plusieurs heures).

   Alternativement, en Scala, on peut écrire les fichiers en parallèle. La méthode `TIW6RDDUtils.writePairRDDToHadoopUsingKeyAsFileName` (définie dans le fichier `TIW6RDDUtils.scala`) permet décrire un RDD de paires de `String`. Pour chaque élément du RDD la première `String` détermine le nom du fichier et la seconde est la ligne qui sera ajoutée dans le fichier en question. Spark va ainsi lire tout le RDD et écrire chaque ligne dans le bon fichier sans qu'il ne soit nécessaire de faire un filtre pour chaque case. La performance est bien meilleure que dans la version précédente (environ 7 min pour partionner les 300 fichiers de `Source` en 122 cases).

4. Créer et sauvegarder sur HDFS un RDD contenant pour chaque rectangle ses
   "coordonnées", c'est à dires les valeurs min et max de RA et DECL pour les
   observations de ce rectangle, ainsi que le nombre d'observations qui ont été
   placées concrètement dans ce rectangle.
5. Créer un programme qui effectue le partionnement et qui prendra en
   particulier en paramètre le répertoire / le fichier des sources à lire, un
   répertoire de sortie, le nombre de bandes _n_ et le nombre objectif _k_
   d'observations voulu par rectangle.
6. Après avoir effectué un partionnement, comparer le nombre d'observations dans
   les rectangles au nombre objectif _k_ et commenter sur la pertinence de la
   répartition.
7. (bonus) Créer un deuxième programme qui prendra en paramètres:

   - une paire de coordonnées DECL et RA
   - une distance max (pour simplifier on prendra la somme des différences sur RA et DECL comme mesure distance)
   - le répertoire contenant les observation partionnées
   - le fichier/répertoire contenant les "coordonnées" des cases
   - un nom de répertoire HDFS de sortie

   et qui placera dans le répertoire de sortie des fichiers csv contenant les
   observations sont la distance au point passé en paramètre est inférieure à la
   distance max passée en paramètre. On prendra soin de ne lire que les
   répertoires `indexed/x-y` nécessaires (i.e. ceux suceptibles de contenir les
   observations suffisement proches)
