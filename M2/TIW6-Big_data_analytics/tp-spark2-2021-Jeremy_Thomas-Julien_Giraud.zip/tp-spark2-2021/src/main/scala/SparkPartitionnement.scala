import TIW6RDDUtils.writePairRDDToHadoopUsingKeyAsFileName
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import schema.PetaSkySchema

import java.lang.Math.{max, min}

object SparkPartitionnement {

  // Parce que notre VM a un problème avec scala et hdfs
  // val compte = "p1704709"
  val compte = "p1914012"
  var cleanFileLines: Option[RDD[Array[String]]] = None

  case class MinMaxMetaData(minRA: Double, maxRA: Double, minDecl: Double, maxDecl: Double, count: Long) {
    def agg(b: MinMaxMetaData): MinMaxMetaData = {
      MinMaxMetaData(
        min(minRA, b.minRA),
        max(maxRA, b.maxRA),
        min(minDecl, b.minDecl),
        max(maxDecl, b.maxDecl),
        count + b.count
      )
    }

    def toValues(): String = {
      minDecl + "," + maxDecl + "," + minRA + "," + maxRA
    }
  }

  def toMinMaxMetaData(input: Array[String]): MinMaxMetaData = {
    MinMaxMetaData(
      input(PetaSkySchema.s_ra).toDouble,
      input(PetaSkySchema.s_ra).toDouble,
      input(PetaSkySchema.s_decl).toDouble,
      input(PetaSkySchema.s_decl).toDouble,
      1
    )
  }

  case class Rectangle(partDecl: Double, partRA: Double) {
    def toId(): String = {
      partDecl + "-" + partRA
    }
  }

  def toRectangle(input: Array[String]): Rectangle = {
    Rectangle(
      input(PetaSkySchema.s_part_decl).toDouble,
      input(PetaSkySchema.s_part_ra).toDouble
    )
  }

  def getCleanFileLines(file: String, sc: SparkContext): RDD[Array[String]] = {
    if (cleanFileLines.isEmpty) {
      cleanFileLines = Option(sc.textFile(file)
        .map(
          _.split(",").map(_.trim)
        ) // transformer chaque ligne en un tableau de String)
        .filter(_(PetaSkySchema.s_sourceId) != "NULL")
      )
    }
    cleanFileLines.get
  }

  def getMinMaxMetaData(
                         file: String,
                         sc: SparkContext
                       ): MinMaxMetaData = {
    getCleanFileLines(file, sc)
      .map(toMinMaxMetaData)
      .reduce((a, b) => a.agg(b))
  }

  /**
   * Retourne l'identifiant de la "case" d'une valeur dans un interval suivant une répartition uniforme.
   * @param n le nombre de "cases" dans l'interval
   * @param width la largeur d'une "case"
   * @param min la valeur minimum de l'interval
   * @param value la valeur dont on cherche la position
   */
  def getCaseIdFromInterval(n: Long, width: Double, min: Double, value: Double): Long = {
    if (width == 0 || min == value) {
      return 1
    }
    val id = Math.ceil(Math.abs(value - min) / width).toLong
    if (id > n) {
      return n
    }
    id
  }

  def getPartDeclFromLine(line: Array[String], n: Long, width: Double, meta: MinMaxMetaData): String = {
    val decl = line(PetaSkySchema.s_decl).toDouble
    val partDecl = getCaseIdFromInterval(n, width, meta.minDecl, decl)
    partDecl.toString
  }

  def getLinesWithPartDecl(
                            n: Long, file: String, sc: SparkContext, width: Double, meta: MinMaxMetaData
                          ): RDD[Array[String]] = {
    getCleanFileLines(file, sc)
      .map(line => line :+ getPartDeclFromLine(line, n, width, meta))
  }

  def getLineWithPartRA(line: Array[String], m: Long, width: Double, min: Double): Array[String] = {
    val ra = line(PetaSkySchema.s_ra).toDouble
    val partRa = getCaseIdFromInterval(m, width, min, ra)
    line :+ partRa.toString
  }

  def getLinesWithPartRA(linesWithPartDecl: Iterable[Array[String]], k: Long): Iterable[Array[String]] = {
    val meta = linesWithPartDecl.map(toMinMaxMetaData).reduce((a, b) => a.agg(b)) // Contient min/max de RA
    val p = linesWithPartDecl.count(_ => true) // Le nombre d'observations dans la bande complète
    val m = Math.ceil(p.toDouble/k).toLong // Le nombre de rectangles
    val width = Math.abs(meta.maxRA - meta.minRA) / m
    val linesWithPartRA = linesWithPartDecl.map(line => getLineWithPartRA(line, m, width, meta.minRA))
    linesWithPartRA
  }

  def getLinesWithPartDeclAndPartRA(linesWithPartDecl: RDD[Array[String]], k: Long): RDD[Array[String]] = {
    // Map<part_decl, observation :+ part_decl>
    val linesByPartDecl = linesWithPartDecl.groupBy(line => line(PetaSkySchema.s_part_decl))
    // List<observation :+ part_decl :+ part_ra>
    val linesByPartDeclWithPartRA = linesByPartDecl.flatMap(elem => getLinesWithPartRA(elem._2, k))
    linesByPartDeclWithPartRA
  }

  def saveRectangles(linesWithPartDeclAndPartRA: RDD[Array[String]], saveFile: Boolean): Unit = {
    val nbCases = linesWithPartDeclAndPartRA.count().toInt
    val dir = "/user/" + compte + "/indexed-julien/"
    val rddToWrite = linesWithPartDeclAndPartRA.map(line => {
      val partDecl = line(PetaSkySchema.s_part_decl)
      val partRA = line(PetaSkySchema.s_part_ra)
      val value = line.reduce((a, b) => a + "," + b)
      (partDecl + "-" + partRA, value)
    })
    if (saveFile) {
      writePairRDDToHadoopUsingKeyAsFileName(rddToWrite, dir, nbCases)
    }
  }

  def getRectanglesMetaData(linesWithPartDeclAndPartRA: RDD[Array[String]]): RDD[(Rectangle, MinMaxMetaData)] = {
    val rectanglesMetaData: RDD[(Rectangle, MinMaxMetaData)] = linesWithPartDeclAndPartRA
      .map(line => (toRectangle(line), toMinMaxMetaData(line))) // List<(Rectangle, MinMaxMetaData)>
      .groupByKey() // Map<Rectangle, List<MinMaxMetaData>>
      .map(elem => (elem._1, elem._2.reduce((a, b) => a.agg(b)))) // Map<Rectangle, MinMaxMetaData>
    rectanglesMetaData
  }

  def saveRectanglesMetaData(rectanglesMetaData: RDD[(Rectangle, MinMaxMetaData)], saveFile: Boolean): Unit = {
    val nbCases = rectanglesMetaData.count().toInt
    val dir = "/user/" + compte + "/indexed-metadata-julien/"
    val rddToWrite = rectanglesMetaData.map(line => (line._1.toId(), line._2.toValues()))
    if (saveFile) {
      try {writePairRDDToHadoopUsingKeyAsFileName(rddToWrite, dir, nbCases)}
    }
  }

  def getMoyenneEcart(values: RDD[Double], seuil: Double): Double = {
    values.reduce((a, b) => Math.abs(a - seuil) + Math.abs(b - seuil)) / values.count()
  }

  /**
   * Effectue les opérations à partir des paramètres du programme.
   * @param n le nombre de bandes
   * @param file l'adresse du fichier à lire
   * @param sc le contexte
   * @param saveFile permet de rendre optionnel l'écriture des résultats
   * @param k objectif d'observations par rectangle
   */
  def doMain(n: Long, file: String, sc: SparkContext, saveFile: Boolean, k: Long,
             versionAlternativePartie4: Boolean, output: String): Unit = {
    // Objectif partie 1 : List<observation :+ part_decl>
    val meta = getMinMaxMetaData(file, sc)
    val width = Math.abs(meta.maxDecl - meta.minDecl) / n
    val linesWithPartDecl = getLinesWithPartDecl(n, file, sc, width, meta)

    // Objectif partie 2 : List<observation :+ part_decl :+ part_ra)
    val linesWithPartDeclAndPartRA = getLinesWithPartDeclAndPartRA(linesWithPartDecl, k)

    // Partie 3
    saveRectangles(linesWithPartDeclAndPartRA, saveFile)

    // Objectif partie 4 : (List) Map<Rectangle, MinMaxMetaData>
    val rectanglesMetaData = getRectanglesMetaData(linesWithPartDeclAndPartRA)
    if (!versionAlternativePartie4) {
      rectanglesMetaData.saveAsTextFile(output)
    } else {
      // La version alternative utilise le même système que la patie 3 avec writePairRDDToHadoopUsingKeyAsFileName
      saveRectanglesMetaData(rectanglesMetaData, saveFile)
    }

    // Partie 6
    // Tous les calculs sont arrondis à l'entier le plus proche
    val counts = rectanglesMetaData.map(elem => elem._2.count.toDouble)
    val moyenneObservationsParRectangle = counts.reduce((a, b) => a + b) / counts.count()
    val moyenneEcartsObjectif = getMoyenneEcart(counts, k)
    val moyenneEcartsObjectifRelative = Math.abs(moyenneEcartsObjectif - k) / k
    println(s"n : $n, k : $k, " +
      s"moyenneObservationsParRectangle : $moyenneObservationsParRectangle, " +
      s"moyenneEcartsObjectif : $moyenneEcartsObjectif, " +
      s"moyenneEcartsObjectifRelative (score) : $moyenneEcartsObjectifRelative\n")
    moyenneObservationsParRectangle
  }

  def main(args: Array[String]): Unit = {
    if (args.length != 6) {
      val help = Array(
        "sourceFile (:path)",
        "n (nombre de bandes: number)",
        "saveFile (true/false)",
        "k (objectif observations par rectangle: number)",
        "versionAlternativePartie4 (true/false)",
        "output (utilisé si versionAlternativePartie4=false: path)"
      ).reduce((a, b) => a + ", " + b)
      println("Usage : " + help)
      return
    }
    val conf = new SparkConf().setAppName("SparkPartitionnement-" + compte)
    val sc = new SparkContext(conf)
    val file = args(0)
    val nbBandes = args(1).toLong
    val saveFile = args(2) == "true"
    val k = args(3).toLong
    val versionAlternativePartie4 = args(4) == "true"
    val output = args(5)
    println(s"params :\nnbBandes : $nbBandes\nfile : $file\nsaveFile : $saveFile\nk : $k" +
      s"\nversionAlternativePartie4 : $versionAlternativePartie4\noutput : $output")
    doMain(nbBandes, file, sc, saveFile, k, versionAlternativePartie4, output)
  }
}
