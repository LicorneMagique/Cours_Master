import SparkPartitionnement.doMain
import org.apache.spark.{SparkConf, SparkContext}
import org.scalatest.{BeforeAndAfter, FunSuite}

class SparkPartitionnementTest extends FunSuite with BeforeAndAfter {

    var sc: SparkContext = null;

    // exécuté avant chaque test
    before {
      // configuration de Spark
      val conf = new SparkConf()
        .setAppName("SparkPartitionnementTest")
        .setMaster("local") // ici on configure un faux cluster spark local pour le test
      sc = new SparkContext(conf)
    }

    test("Test main") {
      val nbBandes = 50
      // val file = "samples/source-sample"
      val file =  "samples/Source-001.csv"
      Array(/*10, 20, 30,*/ 40/*, 50, 60, 70, 80, 90, 100*/).foreach(k => {
        doMain(nbBandes, file, sc, false, k, true, "")
      })
    }

    // exécuté après chaque test
    after {
      sc.stop() // a ne pas oublier, car il ne peut pas y avoir 2 contextes spark locaux simultanément
    }
}
